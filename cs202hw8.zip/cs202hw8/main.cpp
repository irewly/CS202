/*
 * Name: Irene Wang, 5005298618, Assignment 8
 * Description: This program will read in three csv files, one will throw a file
 * not found error, one will throw a file size too large error, and the correct
 * one will then be processed. It's contents will be tokenized into various varaibles
 * that will be stored in a "transaction" object which will then be pushed back into
 * a vector containing various "transaction" objects. After which there will be a bad
 * allocation error that will be caught and a error message will print to the screen.
 * After that there will be a invalid length error that will be caught with error
 * message printed to the screen as well. Lastly, the user will be asked to input a
 * number of objects which they wish to sort between 1-25. If they input a number that
 * is greater than 25, an out-of-bounds error will be thrown and caught with error
 * message printed to the terminal as well. If they did input a valid number, then the
 * sorted number of items will be printed to the terminal.
 * Input: wrongfile.csv, bigFile.csv, SalesJan2009.csv
 * Output: Reading file message, various error messages, number of records to sort
 * prompt, sorted record items
 */
#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <typeinfo>
#include "date.h"
#include "transaction.h"
using namespace std;

// This function will parse the line and return a 
//		brand new transaction object with the
//		data that was parsed. 
Transaction parse(string record)
{
	/******************************************************/
	/*					Your Code Here 					  */
	/*------------- v	v	v	v	v	v	v ------------*/
	stringstream sstream(record); //stringstream used for getline to extract data from record
	string temp;//temporary string used to store data extracted through getline
	
	//variables to pass through "Date" object "d" constructor
	int year = 0;
	int month = 0;
	int day = 0;
	int hour = 0;
	int minute = 0;
	getline(sstream, temp, '/');
	month = stoi(temp);
	getline(sstream, temp, '/');
	day = stoi(temp);
	getline(sstream, temp, ' ');
	year = stoi(temp);
	getline(sstream, temp, ':');
	hour = stoi(temp);
	getline(sstream, temp, ',');
	minute = stoi(temp);
	//create "Date" object "d"
	Date d(year, month, day, hour, minute);

	//variables to pass through "Transaction" object "t" constructor
	string product;
	int price;
	string paymentType;
	string name;
	string city;
	string state;
	string country;
	getline(sstream, temp, ',');
	product = temp;
	getline(sstream, temp, ',');
	price = stoi(temp);
	getline(sstream, temp, ',');
	paymentType = temp;
	getline(sstream, temp, ',');
	name = temp;
	getline(sstream, temp, ',');
	city = temp;
	getline(sstream, temp, ',');
	state = temp;
	getline(sstream, temp, ',');
	country = temp;
	//create "Transaction" object "t"
	Transaction t(d, product, price, paymentType, name, city, state, country);
	
	return t;
	/*------------- ^	^	^	^	^	^	^ ------------*/
	/******************************************************/
}

// Function to return the filesize in bytes
int fileSize(string filename)
{
	ifstream in_file(filename,ios::binary);
	in_file.seekg(0,ios::end);
	int file_size=in_file.tellg();

	return file_size;
}

// Function to readfile and return vector of Transaction objects.
vector<Transaction> readFile(string filename)
{
	vector<Transaction> transactions;
	string line;

	/******************************************************/
	/*					Your Code Here 					  */
	/*------------- v	v	v	v	v	v	v ------------*/
	
	/* (YOUR CODE) (1) Begin the try block */
	try{
		ifstream myFile(filename);	// Open the file
		/* (YOUR CODE) (2) If file is not opened, throw the FileName  */
		if(myFile.fail()){
			throw filename;
		}	
		/* (YOUR CODE) (3) If file is too big (bigger than 5000), throw the file size */
		else if(fileSize(filename) > 5000){
			throw fileSize(filename);
		}
		else{
			// No exceptions were thrown, continue with reading the file
			int lineCount=0;
			while(getline(myFile,line))
			{
				//Parse the line here ignoring the first line
				if(lineCount>0)
				{
					transactions.push_back(parse(line));
				}
				lineCount++;
			}
		}	
	}
	/* (YOUR CODE) (4) end the try block */
	/* (YOUR CODE) (5) Catch Block for FileName */
	catch(string filename){
		cout << "File " << filename << " not found." << endl;
	}
	/* (YOUR CODE) (6) Catch Block for FileSize */
	catch(int filesize){
		cout << "File size: " << filesize << ". Limit exceeded." << endl;
	}

	/*------------- ^	^	^	^	^	^	^ ------------*/
	/******************************************************/
	return transactions;
}


// Template function to sort and print
// This function will sort the Names, Dates, and Price
// (Look at the end of main)
// After sorting within the size, it will print the list
template <class T>
void sortAndPrint(vector<T> records,int size)
{
	/******************************************************/
	/*					Your Code Here 					  */
	/*------------- v	v	v	v	v	v	v ------------*/
	bool stillSorting = true; //boolean to check to see if the vector is completely sorted
	//bubble sort for loop
    for(int i = 0; i < size && stillSorting; i++){
        stillSorting = false;
        for(int j = 0; j < size-1-i; j++){
            if(records[j] > records[j+1]){
				//"switch" left and right vector contents
				T temp = records[j+1]; //temp variable for storing left value
    			records[j+1] = records[j];
    			records[j] = temp;
                stillSorting = true;
            }
        }
    }
	
	for(int k = 0; k < size; k++){
		cout << records[k] << endl; //print out sorted vector content
	}
	/*------------- ^	^	^	^	^	^	^ ------------*/
	/******************************************************/
}

// Main
int main()
{
	//Wrong file name
	string wrongFile="wrongfile.csv";
	//Big file name
	string bigFile="bigFile.csv";
	//Correct file name
	string file="SalesJan2009.csv";
	//vector to hold all the transactions
	vector<Transaction> transactions;

	// Should catch exception ( Not Opened )
	cout<<"Reading wrongfile.csv"<<endl;
	transactions=readFile(wrongFile);
	// Should catch exception ( Too Big ) 
	cout<<"Reading bigFile.csv"<<endl;
	transactions=readFile(bigFile);
	// Should be fine!
	cout<<"Reading SalesJan2009.csv"<<endl;
	transactions= readFile(file);

	cout <<"File read."<<transactions.size()<<" transactions returned"<<endl;

	/******************************************************/
	/*					Your Code Here 					  */
	/*------------- v	v	v	v	v	v	v ------------*/
	
	//-------------- Exception #1 ----------------//
	/* (YOUR CODE) (1) Begin try block */
	try{
		// This is intentionally bad code. 
		// The loop will infinitely try to allocate all of this memory and eventually fail
		while(true){
			new int[10000000000000000ul];
		}
	}	
	/* (YOUR CODE) (2) End try block */
	/* (YOUR CODE) (3) Begin catch block
		*hint* The catch will be type "const bad_alloc&" 
		use "what()" to print the error
	*/
	catch(const bad_alloc& error){
		cout << "Allocation Failed. " << error.what() << endl;
	}
	/* (YOUR CODE) (4) End Catch Block  */
	//--------------------------------------------//

	//Vectors for sorting
	vector<string> names;
	vector<int> price;
	vector<Date> dates;
	
	//-------------- Exception #2 ----------------//
	/* (YOUR CODE) (5) Begin try block */ 
	try{
		// Vector (max_size() + 1) will be too big. 
		names.resize(names.max_size()+1);
		price.resize(price.max_size()+1);
		dates.resize(dates.max_size()+1);
	}
	/* (YOUR CODE) (6) End try block */
	/* (YOUR CODE) (7) Begin catch block
		*hint* The catch will be type "const length_error&" 
		use "what()" to print the error
	*/
	catch(const length_error& error){
		cout << "Length error. " << error.what() << endl;
		/* (YOUR CODE) (8) Resize the 3 arrays to 25 */
		names.resize(25);
		price.resize(25);
		dates.resize(25);
	}	
	/* (YOUR CODE) (9) End catch block */
	//--------------------------------------------//
	

	//-------------- Exception #3 ----------------//
	/* (YOUR CODE) (10) Begin try block */ 
	try{
		int number;
		cout <<"Enter the number of records to sort(1-25):";
		cin>>number;	
			//Populating the vectors from transactions
			for(int i=0;i<number;i++)
			{
				names.at(i)=transactions[i].getName();
				price.at(i)=transactions[i].getPrice();
				dates.at(i)=transactions[i].getDate();
				
			}
			sortAndPrint(names,number);
			sortAndPrint(dates,number);
			sortAndPrint(price,number);
	}
	/* (YOUR CODE) (11) End try block */
	/* (YOUR CODE) (12) Begin catch block
		*hint* The catch will be type "out_of_range" 
		use "what()" to print the error
	*/
	catch(out_of_range error){
		cout << "Number of records to sort exceeded the maximum vector size. " << error.what() << endl;
	}
	//--------------------------------------------//

	/*------------- ^	^	^	^	^	^	^ ------------*/
	/******************************************************/

	return 0;
}