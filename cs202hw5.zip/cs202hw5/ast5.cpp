//Skeleton Code by: Jorge Fonseca
//Assignment Created by Jorge Fonseca
//All Copyrights to Jorge Fonseca, Do not share outside of UNLV CS202 class.
/*
 * Name: Irene Wang, 5005298618, Assignment 5
 * Description: This program will generate a 2D dynamically allocatted array
 * of pointers that stores a pointer to various gadget objects. It will cout
 * the gadgets currently used and autogenerate a gadget.h file through
 * skynet.cpp.
 * Input: Commandline arguments (for gadget.source and gadget.h file names)
 * Output: Current gadgets in use, gogogadget for specific gadgets, 
 * gogogadget for all gadgets. 
 */
#include<iostream>
#include<string>
#include<fstream>
using namespace std;

//Everything is an entity type. They're like midichlorians
class ent_t{
public:
    ent_t(string name) : name(name){} //ent_t constructor
    virtual ~ent_t() = 0; //Virtual Destructor
    string getName() const {return name;} //getter function, returns entity name for public use
private:
    string name; //entity name
};
ent_t::~ent_t(){} //This makes it so you cannot make ent obj but you can of any derived class :D

//Abstract Super Class of All Gadget types
class gadget_t : public ent_t{
public:
    gadget_t(string name) : ent_t(name){}
    //YOUR CODE HERE: One line of code where you make a PURE VIRTUAL void function called gogogadget() with no parameters.
    virtual void gogogadget() = 0;
};

//Inspector Gadget Type
class IG_t : public ent_t{
public:
    /************ CODE HERE **************************************************/
    // v v v v v v v v v v v v v v v v v v v v v v v v 
    //YOUR CODE HERE (Finish the Constructor)
    //This constructor is using inline constructor method with ent_t
    IG_t(int le=3, int wi=3, string file = "gadgets.list") : ent_t("Inspector Gadget"){
        // Next, assign the params to l and w
        l = le; //set l equal to parameter le
        w = wi; //set w equal to parameter wi
        // Last, allocate the memory necessary for a 2D Array (gadget_t*** g)
        gadgets = new gadget_t **[l];
        // Each cell contains a pointer to a gadget (not the object). 
        for(int i = 0; i < l; i++){
            gadgets[i] = new gadget_t *[w];
        }
        // Make sure all of these pointers = nullptr 
        for(int i = 0; i < l; i++){
            for(int j = 0; j < w; j++){
                gadgets[i][j] = nullptr;
            }
        }
        build(file); //call build file with gadgets.list
    }
    //^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ 
    /************ END CODE **************************************************/

    void build(string); //function declaration

    /************ CODE HERE **************************************************/
    // v v v v v v v v v v v v v v v v v v v v v v v v 
    ~IG_t(){
        //YOUR CODE HERE
        //Properly delete the 2D array g
        for(int i = 0; i < l; i++){
            for(int j = 0; j < w; j++){
                delete gadgets[i][j];
            }
            delete [] gadgets[i];
        }
        delete [] gadgets;
    }
    //^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ 
    /************ END CODE **************************************************/

    void gogogadget(string); //Calls gogogadget on specified object in the array
    void printGadgets(); //Prints all gadget names
    void gogogadgetALL(); //Triggers all gadgets lol
private:
    int l,w; //length and width dimensions of gadgets array
    gadget_t ***gadgets; //2D dynamic array of pointers
};

/************ CODE HERE **************************************************/ 
// v v v v v v v v v v v v v v v v v v v v v v v v 
void IG_t::printGadgets(){ //Prints all gadget names
    cout << "List of Currently Available Gadgets:" << endl;
    //YOUR CODE HERE
    //Go through the 2D array and print the names of any gadgets
    // that are not nullptr
    for(int i = 0; i < l; i++){
        for(int j = 0; j < w; j++){
            if (gadgets[i][j] != nullptr){
                cout << gadgets[i][j]->getName() << ", ";
            }
        }
    }
    /* *EXAMPLE* 
    List of Currently Available Gadgets:
        Binoculars, Coat, Brella, 
        Copter, Springs, Neck, 
    */
    cout << endl;
}
//^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ 
/************ END CODE **************************************************/

/************ CODE HERE **************************************************/
// v v v v v v v v v v v v v v v v v v v v v v v v 
void IG_t::gogogadgetALL(){ //Triggers all gadgets lol
    cout << "Go go Gadget All!\n" << endl;
    //YOUR CODE HERE
    //Go through the 2D array and print the names of any gadgets
    // as well as call their gogogadget() function
    for(int i = 0; i < l; i++){
        for(int j = 0; j < w; j++){
            if (gadgets[i][j] != nullptr){
                cout << endl;
                cout << gadgets[i][j]->getName() << ":" << endl;
                gadgets[i][j]->gogogadget();
            }
        }
    }
    cout << endl;
    /* *EXAMPLE*
    Go go Gadget All!

    Binoculars:
        Binoculars lower down out of his hat and over his eyes.

    etc....
    */
}
//^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ 
/************ END CODE **************************************************/

#include "gadgets.h"  //THIS INCLUDES THE AUTO GENERATED FILE

/************ CODE HERE **************************************************/
// v v v v v v v v v v v v v v v v v v v v v v v v 
//Reads through the file and allocates the memory for the gadgets
//in the file

//this function will be called twice, hence the ability to "upgrade"
void IG_t::build(string file){ 
    //This "static bool" means that this bool will only be declared once
    // for all build() function calls. After the first call of this function,
    // upgrade will be updated to true. 
    static bool upgrade = false; 
    bool check = false; //used to break out of nested for loop

    //YOUR CODE HERE
    // If upgrade is true, print "Hmm, Upgrades." (will be false 1st call)
    // Then, set upgrade to true.                   (will be true 2nd call) 
    if(upgrade == true){
        cout << endl;
        cout << "Hmm, Upgrades." << endl;
        //reset all spots in array to nullptr
        for(int i = 0; i < l; i++){
            for(int j = 0; j < w; j++){
                delete gadgets[i][j];
            }
        }      
    }

    //Now, open the file (its the parameter)
        //This file is either gadgets.list or gadgets.list2
    // Read until the end of the file. For every gadget found
    // find a place in the 2D array g for the gadget. 
    // use magic function so the array-cell can recieve the correct gadget
    ifstream fin;
    fin.open(file.c_str());
    string temp; //temporary string for storing getline
    //nested for loop for calling magicfunction on each object read in through fin
    //check used to break out of nested for loop when it is at the end of the file
    for(int i = 0; i < l && !fin.eof() && check == false; i++){
        for(int j = 0; j < w && check == false; j++){
            getline(fin,temp);
            if(temp == ""){//since fin.eof() reads past the end of file, there will be an empty string read in
                check = true;
            }
            else{
                magicfunction(&gadgets[i][j], temp);
            }    
        } 
    }

    upgrade = true; //upgrade set to true after build gets called the first time
}
//^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ 
/************ END CODE **************************************************/


/************ CODE HERE **************************************************/
// v v v v v v v v v v v v v v v v v v v v v v v v 
//LAST FUNCTION ALMOST DONE
//For calling go-go gadget. We need to search which pointer, 
//if any are pointing to a gadget by this name
void IG_t::gogogadget(string match){
    //Iterate through gadgets and look for the gadget 
    //that was passed as the string parameter
    //YOUR CODE HERE
    //If you find it, call its gogogadget()
    bool check = false; //used to break out of nested for loop once gadget is found
    string name; //to access name stored in gadgets array

    //gadget search for loop
    for(int i = 0; i < l && check == false; i++){
        for(int j = 0; j < w && check == false; j++){
            if(gadgets[i][j] != nullptr){
                name = gadgets[i][j]->getName();
                if (name == match){
                    cout << "Go Go Gadget " << match << ": ";
                    gadgets[i][j]->gogogadget();
                    check = true;
                }
            }
        }
    }

}
//^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ 
/************ END CODE **************************************************/

int main(){
    Binoculars Test;
    IG_t InspectorGadget;
    InspectorGadget.gogogadget("Binoculars");
    InspectorGadget.printGadgets(); //Prints all gadget names
    InspectorGadget.build("gadgets.list2"); //This will cout 'hmm upgrades' 
    //cause you are calling build more than once. Use Static for that.
    //ent_t e("Test"); //Should give an error by design
    InspectorGadget.gogogadgetALL(); //Triggers all gadgets lol
    InspectorGadget.gogogadget("Plane");
    InspectorGadget.gogogadget("Parachute");
    InspectorGadget.gogogadget("Wings");
    InspectorGadget.gogogadget("Glider");
    InspectorGadget.gogogadget("Chopper");
    //Now we are ready to take down THE CLAW! :D GO GO GADGET GG EZ!*/
    return 0;
}
