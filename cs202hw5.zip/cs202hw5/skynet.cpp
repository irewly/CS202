//Skeleton Code by: Jorge Fonseca
//Assignment Created by Jorge Fonseca
//All Copyrights to Jorge Fonseca, Do not share outside of UNLV CS202 class.
//This file will parse gadget.go and build a header file that has
//all our gadget classes and also the magicfunction
//"Shut me down, Machines making machines, how peverse!" -C3PO
/* Sample:
class Binoculars : public gadget_t{
public:
    Binoculars() : gadget_t("Binoculars"){}
    void gogogadget(){
        std::cout << "Binoculars lower down out of his hat and over his eyes." << endl;
    }
};
//Also need magic function, for that makes Massive Meme If Statement that basically 
//also uses the file to generate one case for each gadget
void magicfunction(gadget_t **g, string gadgetName){
    if(gadgetName == "Binoculars"){
        *g = new Binoculars;
        return;
    }
    ///...
    if(gadgetName == "Springs"){
        *g = new Springs;
        return;
    }
    std::cout << "ERROR: Could not add Invalid Gadget: '" << gadgetName << "'" << endl;
}
*/
#include<vector>
#include<string>
#include<iostream>
#include<fstream>
#include<sstream> //for parsing gadgets.source file
using namespace std;

struct gadget {
    string name;
    string description;
};

vector<gadget> readFile(string);
void buildClasses(ofstream&, vector<gadget>);
void buildFunction(ofstream&, vector<gadget>);
int main(int argc, char **argv){
    if(argc != 3){
        cout << "ERROR: Usage: [Executeable] [Gadget File] [Header File Name]\n"
             << "Sample: ./a.out gadgets.source gadgets.h" << endl;
        return 1;
    }
    vector<gadget> list = readFile(argv[1]);
    //for(auto& i : list)cout << i.name << "\n" << i.description << endl;//Debug
    ofstream fout; fout.open(argv[2]);
    buildClasses(fout, list);
    buildFunction(fout, list);
    fout.close();
    return 0;
}

/************ CODE HERE **************************************************/
// v v v v v v v v v v v v v v v v v v v v v v v v 
vector<gadget> readFile(string fname){
    ifstream f; f.open(fname.c_str());
    vector<gadget> list;
    gadget g; //temporary struct to be push backed into the vector
    string temp; //temporary string to read in file contents
    string gD; //for temporarily storing gadget description
    string nameLine; //for temporarily storing gadget name part (before the :)
    bool foundName = false; //used as marker for storing word after "Gadget", which is the gadget name
    getline(f, temp); //throw away first line
    
    //YOUR CODE HERE
    //In this while loop, you must parse through gadgets.source.
        // list is a vector of gadgets. Once you have read the gadget name 
        // and description, store them into a gadget and add it to the vector. 

    //Some gadgets are on the same line as others
        // This means they have the same description
        // You still must add all gadgets
        // For example, Arms, Legs, and Neck all have the same description
    while(!f.eof()){
        
        getline(f,nameLine,':'); //obtain gadget name portion - before ":"
        stringstream sstream(nameLine); //stringstream used so the name portion can be fed in word by word
       
        while(sstream >> temp){ //while loop to feed in "nameLine" word by word
            
            //if the word "Gadget" is found, this means that the word after it will be the gadget name
            //thus foundName is set to true
            if(temp == "Gadget"){
                foundName = true;
            }

            //if "temp" is not "Gadget" yet "foundName" is true, this means that "temp" is the gadget name
            else if(foundName == true){
                g.name = temp;
                g.description = ""; //initialize to empty string for later identification
                list.push_back(g); //push back into vector "list"
                foundName = false; //reset foundName to false
            }
        }

        getline(f,temp,' ');//get rid of extra space before description
        getline(f,gD); //read in gadget description

        //for loop to set the description into the corresponding vector cells
        for(int i = 0; i < list.size(); i++){
            if(list[i].description == ""){
                list[i].description = gD;
            }
        }
    }

    f.close(); //close ofstream file
    return list;
}
//^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ 
/************ END CODE **************************************************/

/************ CODE HERE **************************************************/
// v v v v v v v v v v v v v v v v v v v v v v v v 
void buildClasses(ofstream &fout, vector<gadget> list){
    //YOUR CODE HERE
    //(CHECK THE SAMPLE UP ABOVE IN COMMENTS to write correct code)
    //The ofstream will be "gadgets.h", which is the header file we are generating
        //For all gadgets in the vector: 
            // Write to the file the code necessary to create a class for the gadget
            // The gadget class will inherit from the gadget_t class
            // The gadget class has 1 function called "void gogogadget()"
                // This function prints the description.  
    //skynet.cpp credit            
    fout << "//////Autogenerated by skynet.cpp" << endl;

    //for loop to generate all gadget classes hard code and print them out to gadget.h file
    for(int i = 0; i < list.size(); i++){
        fout << "class " << list[i].name << " : public gadget_t{" << endl;
        fout << "public:" << endl;
        fout << "    " << list[i].name << "() : gadget_t(\"" << list[i].name << "\"){}" << endl;
        fout << "    void gogogadget(){" << endl;
        fout << "        std::cout << \" " << list[i].description << "\" << endl;" << endl;
        fout << "    }" << endl;
        fout << "};" << endl << endl;
    }
}
//^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ 
/************ END CODE **************************************************/

/************ CODE HERE **************************************************/
// v v v v v v v v v v v v v v v v v v v v v v v v 
void buildFunction(ofstream &fout, vector<gadget> list){
    //YOUR CODE HERE
    //This function writes the "void magicfunction()" in gadgets.h
    //CHECK THE SAMPLE
    //MagicFunction is taking a double pointer g
        // for all gadgets, you must have one if statement in 
        // magicFunction that will assign *g the new class (which is a gadget)
        // and then returns

    //magicfunction function declaration and definition
    //first if statement
    fout << "void magicfunction(gadget_t **g, string gadgetName){" << endl;
    fout << "    if(gadgetName == \"" << list[0].name << "\"){" << endl;
    fout << "        *g = new " << list[0].name << ";" << endl;
    fout << "    }" << endl;

    //else if statements generation loop
    for(int i = 1; i < list.size(); i++){
        fout << "    else if(gadgetName == \"" << list[i].name << "\"){" << endl;
        fout << "        *g = new " << list[i].name << ";" << endl;
        fout << "    }" << endl;
    }

    //else statement - error message
    fout << "    else{" << endl;
    fout << "        std::cout << \"ERROR: Could not add Invalid Gadget: '\" << gadgetName << \"'\" << endl;" << endl;
    fout << "    }" << endl;
    fout << "}" << endl;

    //skynet.cpp credit
    fout << "//////Autogenerated by skynet.cpp" << endl;
}
//^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ 
/************ END CODE **************************************************/