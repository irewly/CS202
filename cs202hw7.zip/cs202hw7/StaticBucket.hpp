#ifndef STATICBUCKET_H
#define STATICBUCKET_H
#include "Bucket.hpp"
using namespace std;

/*************************************************/
//  YOUR CODE HERE
// v    v   v   v   v   v   v   v   v   v   v   v
//------------------------------------------------
template <class type>
class StaticBucket : public Bucket<type>{
  public:
    StaticBucket();
    void Insert(const type&);
  private:
    int maxsize = 20; //array size set to maxsize
};

template <class type>
StaticBucket<type>::StaticBucket() : Bucket<type>(){ //constructor
    Bucket<type>::arr = new type[maxsize]; //allocate new type array
}

template <class type>
void StaticBucket<type>::Insert(const type& garbage){ //This function will insert garbage into array
    if(Bucket<type>::size >= maxsize){ //check to see if array is full
        cout << "Trashcan array is full and the trash is left in the pile :(" << endl;
    }
    else{
        Bucket<type>::arr[Bucket<type>::size] = garbage; //insert garbage into array
        Bucket<type>::size++; //increase size
    }
}
//------------------------------------------------
// ^    ^   ^   ^   ^   ^   ^   ^   ^   ^   ^   ^
/*************************************************/

#endif