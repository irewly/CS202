/*
 * Name: Irene Wang, 5005298618, Assignment 7
 * Description: This program will sort various "garbages" of different variable
 * types such as int, float, char, and string into their according trash bin classes.
 * The int and char classes are of StaticBucket class and the float and string classes
 * are of the DynamicBucket class, both of which inherit from the class template Bucket.
 * The garbage is inputed through an external txt file. Each garbage item will be stored
 * into a slot in the arr array of the respective garbage bin class. The garbages will also
 * be sorted in ascending order and will be printed out to the terminal in a preformatted
 * fashion.
 * Input: None from terminal. Various int, float, char, and string contents will be ifstreamed
 * from the garbage text file.
 * Output: Garbage bin contents of each of the four garbage bins couted to the terminal in
 * ascending order.
 */
#include <iostream>
#include <fstream>
#include "GarbageProcessor.hpp"

using namespace std;

int main(int argc, char *argv[]){
    if (argc != 2) {
        cout << "ERROR: Invalid Arguments \nUsage: a.out <filename>" << endl;
        return EXIT_FAILURE;
    }

    ifstream in;
    in.open(argv[1]);
    if(in.is_open()){
        string process;
        GarbageProcessor GB;
        while(getline(in,process)){
            GB.InsertItem(process);
        }
        in.close();

        GB.SortGarbage();
        
        cout << endl;
        GB.DisplayBin("int");
        cout << endl;
        GB.DisplayBin("decimal");
        cout << endl;
        GB.DisplayBin("char");
        cout << endl;
        GB.DisplayBin("string");
        return EXIT_SUCCESS;
    }
    else{
        cout << "Could not open file..." << endl;
        return EXIT_FAILURE;
    }
}