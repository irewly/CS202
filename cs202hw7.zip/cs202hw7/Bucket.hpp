#ifndef BUCKET_H
#define BUCKET_H
using namespace std;

template <class type>
class Bucket{
public:
    Bucket();                               //Default Constructor
    ~Bucket();                              //Destructor - Should deallocate array
    int getSize() const;                    //Returns the size
    void Sort();                            //Sorts the Array
    static void Swap(type&, type&);         //Used in the sort function
    type& operator[](int);                  //Overloaded [] for access
    virtual void Insert(const type&) = 0;   //Pure Virtual - need to derive class
protected:
    int size;                               //Size for the array
    type* arr = nullptr;                    //Pointer for the array
};
/*************************************************/
//  YOUR CODE HERE
// v    v   v   v   v   v   v   v   v   v   v   v
//------------------------------------------------
template <class type>
Bucket<type>::Bucket(){ //constructor
    size = 0; //initialize size to 0
}

template <class type>
Bucket<type>::~Bucket(){ //destructor
    if(arr != nullptr){ //if arr has been allocated, de-allocate arr array
        delete [] arr;
    }
}

template <class type>
int Bucket<type>::getSize() const{ //getter function, returns private variable size for public use
    return size;
}

template <class type>
void Bucket<type>::Sort(){ //sort array content in ascending order
    bool stillSorting = true; //boolean to check to see if the array is completely sorted
    for(int i = 0; i < size && stillSorting; i++){
        stillSorting = false;
        for(int j = 0; j < size-1-i; j++){
            if(arr[j+1] < arr[j]){
                Swap(arr[j+1], arr[j]);
                stillSorting = true;
            }
        }
    }
}

template <class type>
void Bucket<type>::Swap(type& l, type& r){ //swap function for bubble sort
    type temp = l; //temp variable for storing l value
    l = r;
    r = temp;
}

template <class type>
type& Bucket<type>::operator[](int index){ //overload [] for public access to arr contents
    return arr[index];
}
//------------------------------------------------
// ^    ^   ^   ^   ^   ^   ^   ^   ^   ^   ^   ^
/*************************************************/
#endif