#ifndef GARBAGEPROCESSOR_H
#define GARBAGEPROCESSOR_H
#include "DynamicBucket.hpp"
#include "StaticBucket.hpp"
#include <string>

class GarbageProcessor{
public:
    static bool IsInteger( const string& ) ;
    static bool IsDecimal( const string& ) ;
    static bool IsChar( const string& ) ;

    void SortGarbage();
    void InsertItem( const string& );

    void DisplayBin( const string& );
private:
    StaticBucket<char> CharBin;
    StaticBucket<int> IntBin;
    DynamicBucket<float> FloatBin;
    DynamicBucket<string> StringBin;
};

/*************************************************/
//  YOUR CODE HERE
// v    v   v   v   v   v   v   v   v   v   v   v
//------------------------------------------------
bool GarbageProcessor::IsInteger(const string &garbage){ //bool function check to see if garbage is an int
    for(int i = 0; i < garbage.length(); i++){ //loop through entire string
        switch(garbage[i]){ //check for numeric char
            case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case '0':{
                continue;   //Continue --> jump back to forLoop
            }
            default:{
                return false; //non-numeric character, not int, return false
            }
        }
    }
    return true; //if made through entire string without returning false, is int, return true
}

bool GarbageProcessor::IsChar(const string &garbage){ //bool function check to see if garbage is a char
    if(garbage.length() == 1){ //check to see if string consists of a single char
        switch(garbage[0]){ //check for numeric char
            case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case '0':{
                return false; //is an int, not char, return false
            }
            default:{
                return true; //not int, must be char, return true
            }
        }
    }
    else{ //if more than 1 char in the string, not char, return false
        return false;
    }
}

void GarbageProcessor::SortGarbage(){ //call sort function on all four bins
    CharBin.Sort();
    IntBin.Sort();
    FloatBin.Sort();
    StringBin.Sort();
}

void GarbageProcessor::InsertItem(const string &garbage){ //insert garbage into correct bin
    if(IsInteger(garbage) == true){ //if garbage is an int
        int temp = 0; //temp variable for storing converted content
        temp = stoi(garbage); //convert garbage to int
        IntBin.Insert(temp);
    }
    else if(IsDecimal(garbage) == true){ //if garbage is a float
        float temp = 0.0f; //temp variable for storing converted content
        temp = stof(garbage); //convert garbage to float
        FloatBin.Insert(temp);
    }
    else if(IsChar(garbage) == true){ //if garbage is a char
        char temp = garbage[0]; //temp variable for storing converted content
        CharBin.Insert(temp);
    }
    else{
        StringBin.Insert(garbage); //if garbage is none of the above, store as string
    }
}

void GarbageProcessor::DisplayBin(const string &bin){ //print out garbage bin content to terminal
    if(bin == "int"){ //print IntBin content
        cout << "/*******************************\\" << endl;
        cout << "   Trying to Display Bin: Int" << endl;
        cout << "\\*******************************/" << endl;
        for(int i = 0; i < IntBin.getSize(); i++){
            cout << " (Item " << i << "): " << IntBin[i] << endl;
        }
        cout << "/*******************************\\" << endl;
        cout << "\\*******************************/" << endl;
        cout << endl;
    }
    if(bin == "decimal"){ //print FloatBin content
        cout << "/**********************************\\" << endl;
        cout << "   Trying to Display Bin: Decimal" << endl;
        cout << "\\**********************************/" << endl;
        for(int i = 0; i < FloatBin.getSize(); i++){
            cout << " (Item " << i << "): " << FloatBin[i] << endl;
        }
        cout << "/**********************************\\" << endl;
        cout << "\\**********************************/" << endl;
        cout << endl;
    }
    if(bin == "char"){ //print CharBin content
        cout << "/*******************************\\" << endl;
        cout << "   Trying to Display Bin: Char" << endl;
        cout << "\\*******************************/" << endl;
        for(int i = 0; i < CharBin.getSize(); i++){
            cout << " (Item " << i << "): " << CharBin[i] << endl;
        }
        cout << "/*******************************\\" << endl;
        cout << "\\*******************************/" << endl;
        cout << endl;
    }
    if(bin == "string"){ //pring StringBin content
        cout << "/*********************************\\" << endl;
        cout << "   Trying to Display Bin: String" << endl;
        cout << "\\*********************************/" << endl;
        for(int i = 0; i < StringBin.getSize(); i++){
            cout << " (Item " << i << "): " << StringBin[i] << endl;
        }
        cout << "/*********************************\\" << endl;
        cout << "\\*********************************/" << endl;
        cout << endl;
    }
}

//------------------------------------------------
// ^    ^   ^   ^   ^   ^   ^   ^   ^   ^   ^   ^
/*************************************************/

bool GarbageProcessor::IsDecimal( const string& s ){
    bool foundPoint = false;                //Locate Decimal
    for(int i = 0; i < s.length(); i++){    //For the entire string
        switch(s[i]){                       //Switch on the char
            //if digit
            case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case '0':{
                continue;   //Continue --> jump back to forLoop
            }
            //if period
            case '.':{      
                if(!foundPoint){        //if a period has not been seen yet
                    foundPoint = true;  //notify
                    continue;           //Continue --> jump back to forLoop
                }
                else{                   //second time seeing decimal
                    return false;       //return false, only one period allowed
                }
            }
            //Non numeric char
            default:{                   //it should have 'continued' by this point. 
                return false;           //return false, this is not a numeric char
            }
        }
    }
    if(foundPoint){                     //Only return true if found at least 1 decimal
        return true;
    }
    else{                               //This was an integer
        return false;                   //Return False
    }
}

#endif