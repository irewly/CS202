#ifndef DYNAMICBUCKET_H
#define DYNAMICBUCKET_H
#include "Bucket.hpp"
using namespace std;

/*************************************************/
//  YOUR CODE HERE
// v    v   v   v   v   v   v   v   v   v   v   v
//------------------------------------------------
template <class type>
class DynamicBucket : public Bucket<type>{
  public:
    void Insert(const type&);
    type *temp; //temporary array pointer used to create array with new increased size
};

template <class type>
void DynamicBucket<type>::Insert(const type &garbage){ //This function will increase array size and insert garbage into array
    (Bucket<type>::size)++; //increase array size
    if(Bucket<type>::size == 1){ //if size equals 1, means first garbage of the bin
        Bucket<type>::arr = new type[1]; //allocate array of size 1
        Bucket<type>::arr[0] = garbage; //insert garbage into array
    }
    else{
        temp = new type[Bucket<type>::size]; //temp gets allocated array with new increased size
        for(int i = 0; i < (Bucket<type>::size)-1; i++){ //copy array content from arr array to temp array
            temp[i] = (Bucket<type>::arr[i]);
        }
        temp[(Bucket<type>::size)-1] = garbage; //insert new content garbage into temp array
        delete [] Bucket<type>::arr; //de-allocate old arr array
        Bucket<type>::arr = temp; //make arr point to new array
        temp = NULL; //reset temp pointer
    }    
}

//------------------------------------------------
// ^    ^   ^   ^   ^   ^   ^   ^   ^   ^   ^   ^
/*************************************************/

#endif