/*
 * Name: Irene Wang, 5005298618, Assignment 10
 * Description: This program will read in an input file containing the number of companies,
 * minimum train load, maximum train load, as well as each of the company names. These info
 * will be stored in corresponding variables and a vector, respectively. The user can then
 * input a list size for the number of wagons they wish to have for the train. Then the user
 * can choose either bubble or insertion sort to sort the wagons from heaviest to lightest.
 * The sorting time will be outputed to the screen.
 * After that, the user can either choose to print out each of the train cars, or choose not
 * to and exit the program. The program creates a Train class that contains the user 
 * specified number of wagons, whose components are contained in individual wagon classes. 
 * The wagons are connected together through a singly linked list. The wagons are allocated 
 * through the Train constructor. The wagons will be deallocated after the end of the program
 * through the Train destructor.
 * Input: train_companies.txt, list length, user choice for bubble/insertion sort, 
 * Output: finished reading input file message, list length prompt, sorting choice prompt, 
 * sorting time, print trains prompt, print out trains (if chosen), exit message
 */
#include <iostream>
#include <fstream>
#include <chrono> 
#include <ctime> 
#include "Train.hpp"
using namespace std;

int main() {
    /*****************************************
     * Reading the File
    *****************************************/
	cout << "Reading the train_companies.txt file..." << endl;
	ifstream in("train_companies.txt");
    string temp; 
	getline(in, temp, ';');
	int numTrains = stoi(temp);
	getline(in, temp, ';');
	int lowerBound = stoi(temp);
	getline(in, temp, ';');
	int upperBound = stoi(temp);
	getline(in, temp);
	vector<string> Companies;
	while(getline(in, temp)){
		Companies.push_back(temp);
	}
	in.close();
	cout << "Done." << endl;

    /*****************************************
     * User selection for Train Length
    *****************************************/
	cout << "Enter list length: ";
	cin >> numTrains; 
    //Create a Train with CONSTRUCTOR here
	Train T(numTrains, Companies, lowerBound, upperBound);
	cout << "List of size " << to_string(numTrains) << " is created." << endl;
	cout << endl;

    /*****************************************
     * User selection for Sorting
    *****************************************/
	cout << "1. Bubble Sort" << endl;
	cout << "2. Insertion Sort" << endl;
	cout << "Selected Sorting Algorithm : ";
	cin >> numTrains;
	cout << endl << "..." << endl << endl; 

    /*****************************************
     * Begin Timer to record sort speed
    *****************************************/
	chrono::time_point<chrono::system_clock> start, end; 
    start = std::chrono::system_clock::now(); 
    //Begin Sort
	if(numTrains == 1){
		T.sortBubble();
	}
	else{
		T.sortInsertion();
	}
    end = std::chrono::system_clock::now(); 
    std::chrono::duration<double> elapsed_seconds = end - start; 
    std::time_t end_time = std::chrono::system_clock::to_time_t(end); 
    std::cout << "Sort finished in:  " << elapsed_seconds.count() << endl << endl;
	
    /*****************************************
     * User input to display the train.
    *****************************************/
	cout << "Display Train? \n(1) Yes\n(2) No\nSelection : ";
	cin >> numTrains;
	if(numTrains == 1){
		T.display();
	}	

    /*****************************************
     * End Program
    *****************************************/
	cout << "ending program..." << endl;
	return 0;
}