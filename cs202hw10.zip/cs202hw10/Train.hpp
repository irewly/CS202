#include <string>
#include <vector>
#include <stdlib.h>     /* srand, rand */
using namespace std;

int RandomNumber(int upperBound, int lowerBound){
	return ( (rand() % (upperBound-lowerBound)) + (lowerBound));
}

class Train{
private:
	struct Wagon{
		string company;
		int load;
		Wagon* next;
	};
	Wagon* head = nullptr;
	int length = 0;
public:
	Train(int numWagons, const vector<string>& Companies, int loadLowerBound, int loadUpperBound);
	~Train();
  Wagon* operator[](int index);
	void swap(Wagon* A, Wagon* B);
	void sortBubble();
	void sortInsertion();
  void display() const;
};

/*****************************************
     * Constructor
       * Initialize a Train object with a linked list
*****************************************/
    /* For the number of Wagons
     - Create a new wagon for the linked list
        - The wagon->Company is a random company from the Vector cmp
        - The wagon->load is a random int between the lB and the uB
     - The last wagon is pointing at nullptr

     Use RandomNumber() to get both a random company and a random weight.

    */
Train::Train(int numWagons, const vector<string>& Companies, int loadLowerBound, int loadUpperBound){
    length = numWagons; //set length to number of wagons (aka list size)
    //insert first train into empty list
    head = new Wagon; 
    head->company = Companies[RandomNumber(Companies.size(),0)]; //random company
    head->load = RandomNumber(loadUpperBound,loadLowerBound); //random weight
    head->next = nullptr; //next ptr is set to null
    for(int i = 1; i < numWagons; i++){ //for loop to create all elements of the wagon linked list
        Wagon* traverse = head;//used to traverse the linked list
        while(traverse->next != nullptr){
            traverse = traverse->next; //traverse through entire linked list until it reaches the last element
        }
        traverse->next = new Wagon; //create new wagon after last element
        traverse->next->company = Companies[RandomNumber(Companies.size(),0)]; //random company
        traverse->next->load = RandomNumber(loadUpperBound,loadLowerBound); //random weight
        traverse->next->next = nullptr; //new wagon's next ptr is set to null
    }
}

/*****************************************
     * Destructor
       * Deallocates entire linked list
*****************************************/
	/*
        Delete the linked list
    */
Train::~Train(){
    Wagon* tmp = head; //temporary pointer
    for(int i = 1; i < length; i++){ //loop through entire linked list
        tmp = head->next; //make tmp point at second element in current list
        delete head; //delete first element of list
        head = tmp; //make head point to the second (now first) element in list
    }
    delete head; //delete last element in list (only one left)
}

/*****************************************
     * Operator []
       * Returns element at index
*****************************************/
    /*
        If the index is >= the size of the list, return nullptr
        Else, return the item in the list located at the index. 
    */
Train::Wagon* Train::operator[](int index){
    if(index >= length){
        return nullptr; //If the index is >= the size of the list, return nullptr
    }
    else{ //Else, return the item in the list located at the index.
        Wagon* tmp = head; //temporary pointer
        if(index == 0){ //accessing first element of list at index 0
            return tmp; //return first element of list
        }
        for(int i = 0; i < index; i++){ //run until it reaches the element at index
            tmp = tmp->next; //traverse to next element
        }
        return tmp; //return element at specified index
    }
}

/*****************************************
     * Swap
       * Swaps 2 adjecent elements in the list
*****************************************/
	/* Remember, you have access to "this->head" (the linked list). 
       Swap A and B in the list - they will be adjacent (right next to each other):
      - You must only alter the pointers ( i.e. wagon->next ). 
      - In order to do this properly, you need to know:
         (1) The first element to be swapped        "L"
         (2) The second element to be swapped       "R"
         (3) The element before the left-most 
             element of A and B in the linked list  "X"
    ---------------------------------------------------
    For example, assume A is the left-most element
     L = A , R = B
    Before Swap:
     ... -> X -> L -> R -> Y -> ...
    After Swap:
     ... -> X -> R -> L -> Y -> ...
    */
void Train::swap(Wagon* A, Wagon* B){
    Wagon* X = head; //set X to head for later traverse
    if(A == head){ //if A is the first element of list
        A->next = B->next; //set A's next pointer to point to element after B
        B->next = A; //set B's next pointer to point to A
        head = B; //set head to point to B (which is now the first element in the list)
    }
    else{
        while(X->next != A){ //traverse until it reaches element before A
            X = X->next;
        }
        X->next = B; //set X's next pointer to point to B
        A->next = B->next; //set A's next pointer to point to the element after B
        B->next = A; //set B's next pointer to point to A
    }
}

/*****************************************
     * Bubble Sort
       * Sorts the train Heaviest->Lightest
*****************************************/
	/*
        Bubble Sort. I recommend using the overload operator 
        (see insertionSort for an idea).
    */
void Train::sortBubble(){
    bool notDone = true; //boolean used to track if all elements have been sorted
    for(int i = 0; i < length && notDone; i++){ //for loop through entire linked list length
        notDone = false; //set to false first
        for(int index = 0; index < length-1-i; index++){ //for loop through unsorted portion
            if((*this)[index]->load < (*this)[index+1]->load){ //if load of element on the left is smaller than element on the right
                swap((*this)[index],(*this)[index+1]); //swap elements of linked list
                notDone = true; //if swap happened, that means we are not done sorting yet
            }
        }
    }  
}

/*****************************************
     * Insertion Sort
       * Sorts the train Heaviest->Lightest
*****************************************/
void Train::sortInsertion(){
	for(int i = 0; i < length; i++){
		int j = i;
		while(j > 0 && (*this)[j]->load > (*this)[j-1]->load){
			swap((*this)[j-1],(*this)[j]);
			j-=1;
		}
	}
}
/*****************************************
     * Display Function
       * Prints the entire train 
*****************************************/
void Train::display() const{
	Wagon* trvs = this->head;
	cout << "Displaying Train :" << endl
		 << "------------------" << endl;

	for(int i = 0; i < this->length; i++){
		cout << endl;
		cout << "/***************\\" << endl;
		cout << "|   Wagon: " << i + 1 << endl;
		cout << "|   " <<trvs->company << endl;  
		cout << "|   Load: " << to_string(trvs->load) << endl;
		cout << "\\***************/" << endl;
		cout << "   [o]     [o]    " << endl;
		cout << endl;
		trvs = trvs->next;
	}
}