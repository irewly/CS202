#ifndef VISITOR_H
#define VISITOR_H

#include "person.h"
/* Visitor class */
class Visitor : public Person
{
public:
	int age; 		//identifier for visitors age
	string inTime; 	//The time the Visitor came in
	string outTime; //The time the Visitor left
    //Member Funcs
	void setVisitorDetails(string name, int age);
    string getName() const;
    int getAge() const;
	void update_the_file(Visitor *ptr, string visitor_file_name);
};

class Review
{
public:
	int art_room;			// How many votes for the Art Room
	int science_room;		// Votes for the Science Room
	int historic_object;	// Votes for the Historic Object
	//Default Constructor
    Review()
    {
    	art_room=0;
    	science_room=0;
    	historic_object=0;
    }
};

#endif