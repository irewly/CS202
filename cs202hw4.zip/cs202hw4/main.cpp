/*
 * Name: Irene Wang, 5005298618, Assignment 4
 * Description: This program is simulating a virtual museum where visitors
 * can log in to enter and log out when they leave. Visitors will be asked
 * to input their name and age upon entry (log in) and answer yes/no to 
 * express whether they liked each of the exhibitions or not upon leaving
 * (log out). Their answers to the questions will be used to calculate the
 * winning exhibition of the day at the end of the program. After the 
 * visitor successfully leaves their name, age, entry time, and exit time 
 * will be printed out to a file titled "Visitor_Log" via ofstream. There 
 * is also an option for staff log in and log out, which works similarly to
 * the visitor functions, except only name is needed upon entry and an 
 * additional staff password is needed for both entry and exit. When a staff
 * successfully leaves, their info will also be printed out to a file ("Staff
 * _Log") via ofstream. The admin option will close down the museum/program.
 * The user will be asked to input the correct admin username and password in
 * order to exit the program. However, if there are any visitors who have not
 * yet logged out, this means they are still in the museum and thus museum 
 * can't close yet. Only after all the visitors are gone will the program 
 * successfully exit. At the very end, the winner of today's exhibition will
 * be couted to the terminal.
 * Input: Option choice (1-5), visitor name, visitor age, visitor votes, 
 * staff name, staff password, admin username, admin password
 * Output: Selection menu, visitor name and age prompts, current visitor 
 * number and their info, current staff in the program, Visitor_Log file, 
 * Staff_Log file, visitor voting prompts, staff name and password prompts,
 * admin username and password prompts, people left in the museum after 
 * closing attempt, winner message.
 */
#include<iostream>
#include<string>
#include<sstream>
#include<fstream> 

#include <fcntl.h>
#include <unistd.h>
#include "entrylog.h"
#include "visitor.h"
#include "staff.h"
#include "person.h"


using namespace std;


int main()
{
	bool exit = false;
	int choice = 0;

    entrylog entry;
    MenuPrint menu;

	while (!exit)
	{

        menu.print_menu();

        cout<<"Enter your choice"<<endl;
		
		cin>>choice;
        //check for input validation
		

		switch (choice)
		{
		case 1:
			/* call the Visitor in */
			entry.visitor_in();
			break;
		case 2:
			/* call the Visitor out */
			entry.visitor_out();
			break;
		case 3:
			/* call the Staff in */
			entry.staff_in();
			break;
		case 4:
			/* call the Staff out */
			entry.staff_out();
			break;
		case 5:
			/* call the exit_main, which is accessible by only admins */
			exit = entry.exit_main();
			break;
		default:
			cout << "Wrong Option! Please choose it again...!";
		}
	}

	int AR = 0; //for storing art room votes
	int HO = 0; //for storing historic object votes
	int SR = 0; //for storing science room votes

    AR = entry.winCount.art_room;
	HO = entry.winCount.historic_object;
	SR = entry.winCount.science_room;

	//if statements for determining winner with highest number of votes
	if(AR == HO && AR == SR){
		cout << "ART_ROOM, HISTORIC_OBJECT, SCIENCE_ROOMS are winner today!" << endl;
	}
	if(AR == SR && AR > HO){
		cout << "ART_ROOM and HISTORIC_OBJECT are winner today!" << endl;
	}
	if(AR == HO && AR > SR){
		cout << "ART_ROOM and HISTORIC_OBJECT are winner today!" << endl;
	}
	if(SR == HO && SR > AR){
		cout << "SCIENCE_ROOM and HISTORIC_OBJECT are winner today!" << endl;
	}
	if(AR > HO && AR > SR){
		cout << "ART_ROOM is the winner today!" << endl;
	}
	if(HO > AR && HO > SR){
		cout << "HISTORIC_OBJECT is the winner today!" << endl;
	}
	if(SR > AR && SR > HO){
		cout << "SCIENCE_ROOM is the winner today!" << endl;
	}
	
	cout << "\nExiting the software, bye! bye!\n";
	return 0;
}



