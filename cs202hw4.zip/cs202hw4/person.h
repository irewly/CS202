#ifndef PERSON_H
#define PERSON_H

#include <iostream>
#include <time.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

using namespace std;
/* Person class */
class Person
{
public:
	string name;
	//Default Constructor.
	Person(){ string name=""; }
};

class MenuPrint
{
public:
	// Main has an object of this class. 
	// It is only used for printing this menu. 
	void print_menu()
	{
		/* Show Menu */
		cout << endl;
		cout << "Welcome to Museum" << endl;
		cout << " 1. Visitor In" << endl;
		cout << " 2. Visitor Out" << endl;
		cout << " 3. Staff In" << endl;
		cout << " 4. Staff out" << endl;
		cout << " 5. Exit" << endl;
	}
};


#endif 