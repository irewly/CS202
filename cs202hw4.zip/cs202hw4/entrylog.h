#ifndef ENTRYLOG_H
#define ENTRYLOG_H

#include "staff.h"
#include "visitor.h"
#include <time.h>
#include <fstream>

using namespace std;

class entrylog
{
  //---------------------------------------------------------
  // All Variables in between the arrows, you must use. 
  //---------------------------------------------------------
  // v  v v v v v v v v v v v v v v v v v v v v v v v v v v v 
  
  //staff info
  Staff *headptr_staff;   //For an array of 100 staff
  int staff_index;        //As staff enter, this index goes up
  string staff_password;  //Staff must enter this on entry/exit
  string staff_file_name; //Staff Log 

  //visitor info
  string visitor_file_name; //For the Visitor_Log
  Visitor *headptr_visitor; //For an array of 100 visitors
  int visitor_index;        //As visitors enter, this index goes up

  //admin info
  string admin_password; //Admin must enter this to close the program
  string admin_username; //Admin must enter this to close the program
  // ^  ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^
  //---------------------------------------------------------
  //---------------------------------------------------------


  /**************************************************************/
  /********* YOU MAY USE THESE TEMP VARIABLES OR NOT ************/
  /**************************************************************/
  int age;            //To temporarily hold the age of a visitor
  char vote;          //To temporarily hold the votes from visitors

  /* Because the entryLog is frequently searching the array
      for staff and visitor names, this bool is used in both 
      OUT functions to determine whether or not the name was found

      in both OUT functions, at the beginning, bool found should 
      be reset to false. 
  */ 
  bool found=false;   //See above
  string tempPass;    //temporary for storing a password entry
  string enteredName; //temporary for storing the Name
  /**************************************************************/
  /**************************************************************/
public:
  Review winCount;  //This class definition is in visitor.h
                    //all it does is count votes for displays

  entrylog();         //default constructor
  ~entrylog();        //DESTRUCTOR
  void visitor_in();  //fuction for visitor-in
  void visitor_out(); //fuction for visitor-out
  void staff_in();    //fuction for staff-in
  void staff_out();   //fuction for staff-out
  bool exit_main();   //fuction for admin-exit
};

#endif
