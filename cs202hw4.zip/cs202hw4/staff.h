#ifndef STAFF_H
#define STAFF_H

#include "person.h"

class Staff : public Person
{
public:
	string inTime; //for inTime info
	string outTime; //for outTime info
	void update_the_file(Staff *ptr,string staff_file_name);
	void setStaffDetails(string name);
    string getName() const;
};

#endif