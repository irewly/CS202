#include "entrylog.h"
#include "visitor.h"
#include "staff.h"
#include "person.h"
#include<string>
#include<sstream>
#include<fstream> 
#include<iostream>
#include <fcntl.h>
#include <unistd.h>

using namespace std;

/* ***********************************************************************
 * function_identifier: This function will store the entry information of
 * a visitor into the headptr_visitor array. It will first prompt the user
 * for the visitor name and age. The information is then stored in a 
 * temporary Visitor pointer vPtr. The entry time will also be accessed 
 * and stored into the vPtr inTime variable. Then, the information will be
 * copied into the actual headptr_visitor array. The vPtr is then 
 * deallocated and the visitor index will increase by one. This function
 * will also print out the names and ages of all visitors currently in the
 * museum through a for loop.
 * parameters: N/A
 * return value: N/A, void function
 * ***********************************************************************/
void entrylog ::visitor_in() //visitor.h
{
	Visitor *vPtr; //visitor pointer
    vPtr = new Visitor;
    
    //visitor information prompts
    cout << "Please enter the visitor name: ";
    cin >> enteredName;
    cout << "Please enter the visitor age: ";
    cin >> age;
    vPtr->setVisitorDetails(enteredName,age);

    //access to current time
    time_t now = time(0);
    string dt = ctime(&now);
    vPtr->inTime = dt;

    //copy vPtr contents into headptr_visitor pointer array
    headptr_visitor[visitor_index].setVisitorDetails(vPtr->getName(),vPtr->getAge());
    headptr_visitor[visitor_index].inTime = vPtr->inTime;

    delete vPtr; //deallocate visitor pointer

    visitor_index ++; //increase visitor index

    //cout all current visitors in the museum to the terminal
    for(int i = 0; i < visitor_index; i++){
        if(headptr_visitor[i].name != ""){
            cout << "visitor-" << i+1 << ":" << headptr_visitor[i].getName();
            cout << "   visitor-" << i+1 << " age:" << headptr_visitor[i].getAge() << endl;
        }
    }
}

/* ***********************************************************************
 * function_identifier: This function will store the exit information of
 * a visitor into the headptr_visitor array. It will first prompt the user
 * for the visitor name. Then it will cycle the name through a for loop to
 * check with the headptr_visitor array and see if it is a valid current 
 * visitor name. If yes, the Visitor_Log file will be updated with the 
 * visitor's pertinent information (including out time). The user will
 * then be prompted to vote for the exhibitions they liked. The votes will
 * be stored in the winCount function for later use. A goodbye message 
 * will cout at the end.
 * parameters: N/A
 * return value: N/A, void function
 * ***********************************************************************/
void entrylog::visitor_out()
{   
    //access to current time
	time_t now = time(0);
    string dt = ctime(&now);

    found = false; //for name search for loop
    int index = 0; //for headptr_visitor array
    Visitor *ptr; //temporary pointer to pass in as update_the_file parameter

    //cout visitor name prompt
    cout << "Please enter the visitor name: ";
    cin >> enteredName;
    //search through headptr_visitor array to see if the name is valid
    for(int i = 0; i < visitor_index && found == false; i++){
        if(headptr_visitor[i].name == enteredName){
            index = i;
            found = true;
        }
    }
    //if name not found in the array, cout error message
    if(found == false){
        cout << "Err: Entered visitor name is not found in the visitor-in list. Try again!" << endl;
    }
    else{
        //store visitor out time
        headptr_visitor[index].outTime = dt;
        //copy information from headptr_visitor into temporary pointer ptr to pass as parameter
        ptr = &headptr_visitor[index];
        headptr_visitor[index].update_the_file(ptr, visitor_file_name);
        //reset visitor name to blank and age to 0
        headptr_visitor[index].setVisitorDetails("", 0);
        //cout voting prompts
        cout << "Please give the votes for the below rooms/objects:" << endl;
        cout << "Do you like Art Rooms(y/n): ";
        cin >> vote;
        if(vote == 'y')
            winCount.art_room ++;
        cout << "Do you like Science Rooms(y/n): ";
        cin >> vote;
        if(vote == 'y')
            winCount.science_room ++;
        cout << "Do you like Historic Object Rooms(y/n: ";
        cin >> vote;
        if(vote == 'y')
            winCount.historic_object ++;
        //cout goodbye message
        cout << "** Thank you for coming! **" << endl;
    }
}

/* ***********************************************************************
 * function_identifier: This function will store the entry information of
 * a staff into the headptr_staff array. It will first prompt the user
 * for the staff name. Then it will ask the user for the staff password.
 * If they enter the correct password, the staff information will be 
 * stored in a temporary Staff pointer sPtr. The entry time will also be 
 * accessed and stored into the sPtr inTime variable. Then, the 
 * information will be copied into the actual headptr_staff array. The 
 * sPtr is then deallocated and the staff index will increase by one. 
 * This function will also print out the names of all staff currently in 
 * the museum through a for loop.
 * parameters: N/A
 * return value: N/A, void function
 * ***********************************************************************/
void entrylog::staff_in()
{   //access to current time
    time_t now = time(0);
    string dt = ctime(&now);

	Staff *sPtr; //staff pointer
    sPtr = new Staff;

    //cout staff name prompt
    cout << "Please enter the staff name: ";
    cin >> enteredName;
    sPtr->setStaffDetails(enteredName);

    //store in time to pointer sPtr
    sPtr->inTime = dt;

    //cout staff password prompt
    cout << "Please enter the staff password: ";
    cin >> tempPass;
    //if user input does not match staff_password, cout wrong password message
    if(tempPass != staff_password){
        cout << "Wrong Staff Password!!! Data entry incomplete..." << endl;
    }
    else{
        //copy staff information from sPtr to headptr_staff pointer array
        headptr_staff[staff_index].setStaffDetails(sPtr->getName());
        headptr_staff[staff_index].inTime = sPtr->inTime;

        staff_index ++; //increase staff index

        delete sPtr; //deallocate staff pointer

        //cout all current staff members in the museum to the terminal
        for(int i = 0; i < staff_index; i++){
            if(headptr_staff[i].name != ""){
                cout << "staff-" << i+1 << ":" << headptr_staff[i].getName() << endl;
            }
        }
    }
}

/* ***********************************************************************
 * function_identifier: This function will store the exit information of
 * a staff into the headptr_staff array. It will first prompt the user
 * for the staff name. Then it will cycle the name through a for loop to
 * check with the headptr_staff array and see if it is a valid current 
 * staff name. If yes, it will ask for the staff password. If the password
 * is correct, the Staff_Log file will be updated with the staff's pertinent 
 * information (including out time). 
 * parameters: N/A
 * return value: N/A, void function
 * ***********************************************************************/
void entrylog::staff_out()
{   
    //access to current time
	time_t now = time(0);
    string dt = ctime(&now);
    
    int index = 0; //for headptr_staff array
    found = false; //for name search for loop
    Staff *ptr; //temporary pointer for update_the_file function parameter

    //cout staff name prompt
    cout << "Please enter the staff name: ";
    cin >> enteredName;

    //search through headptr_staff array to see if the name is valid
    for(int i = 0; i < staff_index && !found; i++){
        if(headptr_staff[i].name == enteredName){
            index = i;
            found = true;
        }
    }
    //if name is not found in the array, cout error message
    if(found == false){
        cout << "Err: Entered staff name is not found in the staff-in list. Try again!" << endl;
    }
    else{
        //cout staff password prompt
        cout << "Enter the staff password: ";
        cin >> tempPass;
        //if user input does not match staff_password, cout wrong password message
        if(tempPass != staff_password){
            cout << "Wrong Password!!!" << endl;
        }
        else{
            headptr_staff[index].outTime = dt;//store staff out time
            ptr = &headptr_staff[index]; //copy from array to temporary pointer
            headptr_staff[index].update_the_file(ptr, staff_file_name);
            headptr_staff[index].setStaffDetails(""); //reset staff name to blank
        }
    }
}

/* ***********************************************************************
 * function_identifier: This function will essentially "close down" the 
 * museum for the day. It will first ask the user to input the admin
 * username and password. If those are correct, the function will loop 
 * through both headptr_visitor and headptr_staff to see if there are any
 * people left in the museum. If there are still visitors in the museum,
 * the function returns false (and thus the close down fails). If not, the
 * function will return true and the close down succeeds.
 * parameters: N/A
 * return value: N/A, void function
 * ***********************************************************************/
bool entrylog::exit_main()
{   
    found = false; //for name search for loop

    //cout admin username prompt
	cout << "Please enter the admin username: ";
    cin >> enteredName;
    //if input does not match admin_username, cout error message and exit fails
    if(enteredName != admin_username){
        cout << "Wrong Admin Username!!!" << endl;
        return false;
    }
    else{
        //cout admin password prompt
        cout << "Please enter the admin password: ";
        cin >> tempPass;
        //if input does not match admin_password, cout error message and exit fails
        if(tempPass != admin_password){
            cout << "Wrong Admin Password!!!" << endl;
            return false;
        }
        else{
            //search through for loop for any visitor that's still in the museum
            for(int i = 0; i < visitor_index; i++){
                if(headptr_visitor[i].name != ""){
                    cout << "Visitor (" << headptr_visitor[i].name << ") is inside" << endl;
                    found = true;
                }
            }
            //search through for loop for any staff that's still in the museum
            for(int i = 0; i < staff_index; i++){
                if(headptr_staff[i].name != ""){
                    cout << "Staff (" << headptr_staff[i].name << ") is inside" << endl;

                }
            }
            //if no visitors are in the museum, exit successes
            if(found == false){
                return true;
            }
            //if there are still visitors, exit fails
            else{
                return false;
            }
        }
    }
}

//entrylog constructor, initializes staff_index, visitor_index,
//admin_username, admin_password, staff_password, staff_file_name,
//visitor_file_name, headptr_staff, and headptr_visitor
entrylog::entrylog()
{ 
	staff_index = 0; //initialize staff_index to 0
    visitor_index = 0; //initialize visitor_index to 0
    admin_username = "admin"; //set admin_username to "admin"
    admin_password = "welcome123"; //set admin_password to "welcome123"
    staff_password = "staff123"; //set staff_password to "staff123"
    staff_file_name = "Staff_Log.txt"; //set staff_file_name to "Staff_Log.txt"
    visitor_file_name = "Visitor_Log.txt"; //set visitor_file_name to "Visitor_Log.txt"
    headptr_staff = new Staff[100]; //initialize and allocate headptr_staff pointer array to 100
    headptr_visitor = new Visitor[100]; //initialize and allocate headptr_visitor pointer array to 100
}

//entrylog destructor, deallocates pointer arrays headptr_staff and 
//headptr_visitor
entrylog::~entrylog()
{
    delete [] headptr_staff; //deallocate headptr_staff pointer array
    delete [] headptr_visitor; //deallocate headptr_visitor pointer array
}
