#include <iostream>
#include <time.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <fstream>
#include "staff.h"
using namespace std;

//setter, sets Staff "name" equal to parameter
void Staff::setStaffDetails(string n)
{
    name = n;
}

//getter, returns Staff "name" for public access
string Staff::getName() const
{
    return name;
}

/* ***********************************************************************
 * function_identifier: This function will open a file with the passed in
 * parameter name via ofstream. Then it will update the Staff_Log file 
 * by printing out relevant info of the staff that just left to the file 
 * via ofstream.
 * parameters: Staff type dereferenced pointer "ptr", string "staff_
 * file_name" (Staff_Log)
 * return value: N/A, void function
 * ***********************************************************************/
void Staff :: update_the_file(Staff *ptr, string staff_file_name)
{
	ofstream oFile;
    oFile.open(staff_file_name.c_str(), ios_base::app|ios_base::out);
    if(oFile.is_open()){
        oFile << "STAFF_ENTRY" << endl;
        oFile << "NAME:     " << name << endl;
        oFile << "IN_TIME:  " << inTime << endl;
        oFile << "OUT_TIME: " << outTime << endl;
        oFile.close();
    }
    else{
        cout << "Unable to open the file." << endl;
    }
}
