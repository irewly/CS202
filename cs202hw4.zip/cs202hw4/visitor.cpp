#include "visitor.h"
#include <iostream>
#include <time.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <fstream>
using namespace std;

//setter, sets Visitor "name" and "age" equal to parameter values
void Visitor::setVisitorDetails(string n, int a)
{
    name = n;
    age = a;
}

//getter, returns Visitor "name" for public access
string Visitor::getName() const
{
    return name;
}

//getter, returns Visitor "age"
int Visitor::getAge() const
{
    return age;
}

/* ***********************************************************************
 * function_identifier: This function will open a file with the passed in
 * parameter name via ofstream. Then it will update the Visitor_Log file 
 * by printing out relevant info of the visitor that just left to the file 
 * via ofstream.
 * parameters: Visitor type dereferenced pointer "ptr", string "visitor_
 * file_name" (Visitor_Log)
 * return value: N/A, void function
 * ***********************************************************************/
void Visitor :: update_the_file(Visitor *ptr,string visitor_file_name)
{
    ofstream oFile;
    oFile.open(visitor_file_name.c_str(), ofstream::app);
    if(oFile.is_open()){
        oFile << "VISITOR_ENTRY" << endl;
        oFile << "NAME:     " << ptr->name << endl;
        oFile << "AGE:      " << ptr->age << endl;
        oFile << "IN_TIME:  " << ptr->inTime << endl;
        oFile << "OUT_TIME: " << ptr->outTime << endl;
        oFile.close();
    }
    else{
        cout << "Unable to open the file." << endl;
    }
}
