#ifndef COLLECTION_H
	#include "Collection.h"
	#define COLLECTION_H
#endif

using namespace std;

//********************** Collection function definitions *****************************

//>> operator definition to read Objects into the Collection. Creates an Object of the generic type and then uses its >> to
//read that Object and add it into our Collection.
template <class U>
istream& operator >> (istream& in, Collection<U>& collection)
{
	U temp;
	in >> temp;
	collection.add(temp);
	
	return in;
}

template <class T>
void Collection<T>::operator = (const Collection<T>& other)
{
	if (data != NULL)
		delete[] data;

	size = other.size;
	count = other.count;
	data = new T[other.size];

	for (int i = 0; i < data.count; i++)
		data[i] = other.data[i]; 
}
