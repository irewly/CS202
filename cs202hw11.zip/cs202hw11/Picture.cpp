#ifndef PICTURE_H
	#include "Picture.h"
	#define PICTURE_H
#endif // !PICTURE_H

//******************************** Picture function implementations ******************************

//Picture version of the fromFile function that Collection has
Picture* Picture::fromFile(string filename)
{
	Picture* result = new Picture;

	ifstream infile(filename);
	Pixel newItem; //Temp item to read into before storing

	while (!infile.eof())
	{
		infile >> newItem; //Read the new item using the >> overload

		if (!infile.eof())
			result->add(newItem); //Push back the item we just read
	}

	return result;
}

//Operator ()
Picture Picture::operator () (const Picture& other)
{
	Picture newPicture = Picture();
	
	if(newPicture.data != NULL){
		delete[] newPicture.data;
	}
	
	newPicture.size = other.size;
	newPicture.count = other.count;
	newPicture.data = new Pixel[other.size];

	for (int i = 0; i < other.count; i++)
		newPicture.data[i] = other.data[i];

	return newPicture;
}

/*****************************************************/
/*					YOUR CODE HERE 					 */
/*	v	v	v	v	v	v	v	v	v	v	v	v	v*/

// Draw() for Picture
void Picture::draw(){
	for(int i = 0; i < size; i++){ //for loop to call the draw function for each pixel stored in data array
		data[i].draw();
	}
}
// Overload Operator =
void Picture::operator= (const Picture& other){
	delete [] data; //deallocate existing data array
	size = other.size; //set this picture's size to "other"'s size
	count = other.count; //set this picture's count to "other"'s count
	data = new Pixel[size]; //allocat new data array with new size
	for(int i = 0; i < size; i++){ //for loop to copy over "other"'s data array contents into this one's data array
		data[i] = other.data[i]; 
 	}
 }
/*---------------------------------------------------*/
/*	^	^	^	^	^	^	^	^	^	^	^	^	^*/
/*****************************************************/

