#include <iostream> 
#include <fstream>
#include <vector>

using namespace std;

//Template Collection which holds the specified data type, T, and contains a few functions to make programming easier.
template <class T> 
class Collection
{
	protected:
		T* data = NULL;
		int count;
		int size;
		const int expansionSize = 4;

	public:
		virtual ~Collection() { try { if (data != NULL) delete[] data; data = NULL; } catch (char* e) {} }

		/*****************************************************/
		/*					YOUR CODE HERE 					 */
		/*	v	v	v	v	v	v	v	v	v	v	v	v	v*/
		Collection() { //Constructor
			size = 5; //set starting size to 5
			data = new T[size]; //allocate data array to starting size
			count = 0; //initialize count to 0
		}

		void add(const T& new_item){ //Add() 
			count++; //increase item count
			if(count > size){ //if this item exceeds array size limit
				int newsize = size + 10; //newsize is a temporary variable used to hold increased size value
				T* tmp = new T[newsize]; //tmp is temporary array with new size
				for(int i = 0; i < size; i++){ //for loop copy old data array value into tmp array
					tmp[i] = data[i];
				}
				delete [] data; //delete old data array
				size = newsize; //update size to newsize
				data = tmp; //data now points to tmp array
			}
			data[count-1] = new_item; //insert new item
		}

		/*---------------------------------------------------*/
		/*	^	^	^	^	^	^	^	^	^	^	^	^	^*/
		/*****************************************************/
		
		//######################### Functions #########################
		//Creates a new Collection from the given file
		static Collection<T>* fromFile(string filename) {
			Collection<T>* result = new Collection<T>;

			ifstream infile(filename);
			T newItem; //Temp item to read into before storing

			while (!infile.eof())
			{
				infile >> newItem; //Read the new item using the >> overload
				if(!infile.eof())
					result.add(newItem); //Push back the item we just read
			}

			return result;
		} 

		//######################### Operators #########################
		T operator [](int index) { return data[index]; }
		void operator = (const Collection<T>& other); //Copies the contents of one Collection to another
		
		Collection<T> operator () (const Collection<T>& other)
		{
			Collection<T> newCollection = Collection<T>();
			if(newCollection.data != NULL){
				delete[] newCollection.data;
			}
			newCollection.size = other.size;
			newCollection.count = other.count;
			newCollection.data = new T[other.size];

			for (int i = 0; i < data.count; i++)
				newCollection.data[i] = other.data[i];

			return newCollection;
		}

		//Declaration of >> operator for reading into a Collection
		template <class U>
		friend istream& operator >> (istream& in, Collection<U>& collection);
};

