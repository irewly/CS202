#ifndef DRAW_H
	#include "DrawObject.h"
	#define DRAW_H
#endif

//****************************** Screen class implementations **************************************
//Sets the character to be drawn at the given x and y coordinate on the screen
void Screen::setDrawChar(int x, int y, char character)
{
	try { 
		if (x < 0 || y < 0 || x >= resX || y >= resY)
			throw out_of_range("Out of range");

		buffer[y][x] = character; //Assign the character if it is in bounds
	}
	catch(out_of_range) { 
		cout << "ERROR: Pixel coordinate given is not in the screen bounds. Resolution is " << resX << "x" << resY << 
			", given x = " << x << " and y = " << y << endl;
	}
}

//Clears all characters on screen to the default character, ' '. This function is optional to use.
void Screen::clearScreen()
{
	int i, j;
	for (i = 0; i < resY; i++)
		for (j = 0; j < resX; j++)
			buffer[i][j] = ' ';
}

//Draws all of the characters currently in the Screen's buffer to cout
void Screen::drawScreen()
{
	int i, j;

	//Draw the top of the frame
	cout << "+";
	for (j = 0; j < resX; j++)
		cout << "-";
	cout << "+" << endl;

	//Draw the sides and middle of the frame
	for (i = 0; i < resY; i++)
	{
		cout << "|";
		for (j = 0; j < resX; j++)
			cout << buffer[i][j];

		cout << "|" << endl;
	}

	//Draw the bottom of the frame
	cout << "+";
	for (j = 0; j < resX; j++)
		cout << "-";
	cout << "+" << endl;
}

//Constructor for the Screen. Allocates the array for drawing and then clears the Screen
Screen::Screen()
{
	buffer = new char* [resY]; //Allocate all of the rows
	for (int i = 0; i < resY; i++) //Allocate the elements for each row
		buffer[i] = new char[resX];

	clearScreen(); //Clear the screen by default to be safe
}

//Destructor for Screen that deallocates the buffer array
Screen::~Screen()
{
	for (int i = 0; i < resY; i++) //Dellocate the elements for each row
		delete[] buffer[i];

	delete[] buffer; //Dellocate all of the rows
}

/*****************************************************/
/*					YOUR CODE HERE 					 */
/*	v	v	v	v	v	v	v	v	v	v	v	v	v*/

// Draw() for Pixel
void Pixel::draw(){
	mainScreen.setDrawChar(x,y,drawChar); //call mainScreen's setDrawChar function to store pixel info in buffer
}
// Overload Operator >>
istream& operator >> (istream& in, Pixel& pixel){
	in >> pixel.x; //read in x coordinate from file
	in >> pixel.y; //read in y coordinate from file
	in >> pixel.drawChar; //read in char used to draw from file
	return in;
}
/*---------------------------------------------------*/
/*	^	^	^	^	^	^	^	^	^	^	^	^	^*/
/*****************************************************/
