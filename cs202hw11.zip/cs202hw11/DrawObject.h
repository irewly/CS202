#include <string>
#include<iostream>
#include <vector>
#include <fstream>

using namespace std; 

//Abstract Object class for things that can be drawn
class DrawObject
{
	protected:
		virtual void draw() = 0; //Abstract draw() function to do an action on the DrawObject that we will define later

		DrawObject() { } //Default constructor 
		virtual ~DrawObject() {}
};

const int resX = 100; //Horizontal resolution of screen to draw to (in chars)
const int resY = 48;  //Vertical resolution of screen to draw to (in chars)

//Screen class for drawing things to the console. This is already implemented for you in Pixel.cpp.
class Screen
{
	static char** buffer; //2D array representing the actual screen we will draw

public:
	static void setDrawChar(int x, int y, char character);
	static void clearScreen();
	static void drawScreen();

	Screen();
	~Screen();
};

//Pixel class that represents a specific Pixel on the Screen. Since this is in ASCII art, each Pixel will be represented by an ASCII character,
//rather than a normal RGBA vector4. Contains the x y coordinate to be drawn at and th character to use. 
class Pixel : public DrawObject
{
	int x = 0, y = 0; //x Coordinate on screen
	char drawChar = '\0'; //Char that this Pixel will be drawn as on the screen
	static Screen mainScreen; //Screen to draw all of our pictures to. Shared across pixels

public:
	void draw(); //Draws this pixel onto the mainScreen
	friend istream& operator >> (istream& in, Pixel& pixel); //>> overload to read a Pixel in from a stream
};
