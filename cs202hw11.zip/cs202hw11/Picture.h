#ifndef DRAW_H
	#include "DrawObject.h"
	#define DRAW_H
#endif
#ifndef COLLECTION_H
	#include "Collection.h"
	#define COLLECTION_H
#endif

//Picture class, which holds a collection of Pixels. Also inherits from DrawObject so that it can draw()
class Picture : public Collection<Pixel>, public DrawObject
{
	public:
		void draw();

		void operator = (const Picture& other);
		Picture operator () (const Picture& other);

		static Picture* fromFile(string filename); 

		Picture() { 
			if(data != NULL) {
				delete[] data;
			}
			data = new Pixel[expansionSize]; count = 0; size = expansionSize; }
};
