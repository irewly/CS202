#ifndef COLLECTION_H
    #include "Collection.h"
    #define COLLECTION_H
#endif

#ifndef DRAW_H
    #include "DrawObject.h"
    #define DRAW_H
#endif

#ifndef PICTURE_H
    #include "Picture.h"
    #define PICTURE_H
#endif // !PICTURE_H

/*********************************************
* This program will take in input files describing an image and then render them each as ASCII art to the terminal.
* Each file contains a list of Pixels that describe an xy coordinate on screen along with the ASCII character to use when drawing that Pixel.
* 
* We have two helper classes that we will inherit from in this assignment: DrawObject and Collection. DrawObject is an abstract class that contains an
* abstract function called draw(). When overridden, draw() will draw whatever object it is included in to the screen. We will see more specifically what 
* this means later. 
* Along with the DrawObject class, we have a template Collection class which supports storing items (via a vector called data) along with a few other 
* helper functions. You can think of it like a vector with some extra features. The main features of it include the ability to 
* create a Collection directly from a file and a >> overload to read from the stream and create an object that matches the 
* generic type that the collection stores.
* 
* Another helper class provided is the Screen class, which holds a 2D array representing a screen space that can be drawn to. The 2D array,
* buffer, has x resolution and y resolution constants representing how wide and tall it is in Pixels, respectively. Along with this, it comes
* with some functions to help with drawing the ASCII art. The setDrawChar(int x, int y, char character) function will set a character to the given 
* character at the x y coordinate provided so that we can draw it later. You will need to set all of these using your Pixels, which will be described 
* later. The drawScreen() function will take the buffer and draw everything in it to the terminal. Last, the clearScreen() function will clear 
* everything in the buffer to be the space character so that it gets drawn as nothing.
* 
* One of the main classes of this assignment is the Pixel class, which are what we will be drawing to the terminal. This class contains x and y 
* coordinates for where it should be drawn to the Screen as well as an ASCII character representing how we will print it. This class also inherits
* from the DrawObject class, meaning that it gets the draw() function. We will need to overload this so that when drawn, the Pixel will place itself
* at its x y coordinate with its character.
* 
* The second class you will need to implement is the Picture class, which contains a vector of Pixels that will need to be drawn. You may notice that
* the Picture class inherits from two classes: DrawObject and Collection. This means that it will get all of the members from both classes.
* From the DrawObject, it will need to implement the abstract draw() function, which should draw all of the Pixels it holds. Inheriting from the
* Collection class will allow it to store Pixels and also inherit its operator overload. You may notice that it specifically inherits from
* Collection<Pixel>. This means that it will only inherit from the version of Collection where the generic type is Pixel, so the Picture class
* itself is not a template class.
* You will need to write two functions for this class. First, the abstract draw function mentioned earlier, and second a new version of the static
* fromFile function inherited from Collection. This will need to open the file given by filename and then read in each line from the file as 
* a Pixel using the >> overload, then store the Pixel in the data vector.
* will be almost the same as Collection<T>::fromFile, except we will return a Picture instead of a collection and we do not have a generic type, so
* T must be a Pixel (since a Picture specifically inherits from Collection<Pixel>).
* 
* Main is already implemented for you. It doesn't do a whole lot. It will create a new Collection of Pictures for us to render.
* Next, we will read all of the Pictures from the provided files and then draw them to the screen. This will use the Picture::fromFile function
* to create a new Picture from each file name given, and then use that Picture to do the drawing.
* 
* Included with the skeleton code is a makefile for your convenience. A makefile is used to compile all of the source files, and can be used to 
* only compile the things that have been changed since you last compiled. In order to use it, include it in the same directory as your source files 
* and type the command "make" into the terminal. You will notice that all it really does is give the g++ command that you would normally type:
* g++ -o aArtist Assignment11.cpp Collection.cpp DrawObject.cpp Picture.cpp
* Hopefully, you can see that just typing make is a little more convenient than having to type all the file names each time.
* If you are programming in Visual Studio, note that it already keeps a makefile for you.
* After compiling, you should see that you get an executable, aDrawer. You can run this as you normally do with ./aDrawer
* It can take any number of arguments, all being the files you want to draw. So, for example:
* ./aArtist unlv.data slide.data
* will draw both the unlv.data and slide.data images. You can put as many files as you like
* 
* INSTRUCTOR NOTES FOR SOLUTION:
* Plan is to have them implement the Picture class to learn about multiple inheritance and then have them implement the operator overload for >>
* and draw() function in Pixel.
* 
*Can add dynamic allocation if we need to make this program more difficult...
**********************************************/

//Static initializers
char** Screen::buffer = NULL; //Set screen's buffer to nothing, we'll allocate it when we create the Screen
Screen Pixel::mainScreen = Screen(); //Make a screen to render everything onto

int main(int argc, char** argv)
{
    Collection<Picture*> mainCollection; //Main Collection containing all other Collections

    //Add new Collections to the Main Collection from the command line arguments
    for (int i = 1; i < argc; i++)
    {
        Screen::clearScreen(); //Clear all of the Pixels off of the screen

        mainCollection.add(Picture::fromFile(argv[i])); //Create a new Collection from a file to hold all of the Pixels
        mainCollection[i - 1]->draw(); //Draw the image we just created

        Screen::drawScreen(); //Draw all of the pixels currently in the screen's buffer
    }

    for (int i = 1; i < argc; i++)
        delete mainCollection[i - 1];

}

