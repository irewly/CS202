/* CS 202 FALL 2020
    This skeleton code was developed by James Piotrowski - UNLV Computer Science
*/

#include <string>
#include <fstream> 
#include "WeaponClass.h"

using namespace std;
/********************************************************************************************************/
/*                              Super Class                                                             */
/********************************************************************************************************/
class PlayerClass{
public:
    PlayerClass();                          // Constructors                             
    PlayerClass( char, string, int, int );  //                                        
    ~PlayerClass();                         //Destructor
    void EquipWeapon( string );             // Will alter the Weapon in the WeaponSlot. 
    void DoDamage( PlayerClass& );          // Will do damage to another player.        
    void TakeDamage( int );                 // A function to subract from HealthPoints. 
    
    char GetPlayerType() const;        // Returns the PlayerType  
    string GetPlayerName() const;      // Returns the PlayerName  
    static int GetPlayerCount(); // Returns the PlayerCount -- This is Static

// Protected Members. Derived class instances will be able to inheret and access these members. Protected is not accesible to anything but the Base Class and Derived Classes. 
protected:  
    string PlayerName;          // PlayerName --> {PlayerType Color} + {PlayerCount} --> i.e. "Red1", "Blue2", "Blue3", "Green4", etc..
    char PlayerType;            // Either 'r', 'b', 'g'
    int Strength;               // Strength Level
    int Skill;                  // Skill Level
    int HealthPoints;           // Health Points --> 25 By default
    WeaponClass WeaponSlot;     // Choice of Weapon
    static int PlayerCount;     // Keeps track of the number of Players. Should be incremented in Constructors -- Notice it is Static   
    ofstream out;               // For the Player Log
};
//Default constructor, initializes Strength, Skill, HealthPoints, 
//PlayerType, and PlayerName to default (null) values. Increases
//PlayerCount by 1 each time;
PlayerClass::PlayerClass(){
    Strength = 0;
    Skill = 0;
    HealthPoints = 25;
    PlayerType = '\0';
    PlayerName = "";
    PlayerCount ++;
}
//Constructor, initializes PlayerType, PlayerName, Strength, Skill,
//HealthPoints to parameter values. Increases PlayerCount by 1. Opens
//ofstream "out" with designated file name and writes spawn message. 
PlayerClass::PlayerClass(char pType, string pName, int pStrength, int pSkill){
    string oFile;
    PlayerType = pType;
    PlayerName = pName;
    Strength = pStrength;
    Skill = pSkill;
    HealthPoints = 25;
    PlayerCount ++;
    oFile = PlayerName + ".txt";
    out.open(oFile.c_str());
    out << PlayerName << " has been spawned." << endl;

}
//Destructor, if playerLog "out" is open, writes to file despawn message,
//then closes file.
PlayerClass::~PlayerClass(){
    if(out.is_open()){
        out << PlayerName << " has been despawned." << endl;
        out.close();
    }
}
int PlayerClass::PlayerCount = 0;
/* ***********************************************************************
 * function_identifier: This function will both cout and write to ofstream
 * a damage message showing the amount of damage. The amount of damage 
 * "dmg" will also be subtracted from the player's HealthPoints.
 * parameters: integer "dmg" for damage
 * return value: N/A, void function
 * ***********************************************************************/
void PlayerClass::TakeDamage(int dmg){
    cout << PlayerName << " has taken " << dmg << " damage!" << endl;
    out << PlayerName << " took " << dmg << " damage." << endl;
    if((HealthPoints - dmg) < 0 ){
        cout << PlayerName << " has reached 0 health! They can no longer battle..." << endl;
        out << PlayerName << " has reached 0 health." << endl;
    }
    else{
        HealthPoints = HealthPoints - dmg;
    }
}
/* ***********************************************************************
 * function_identifier: This function will call TakeDamage function to 
 * actually perform the damage to the player passed into the parameters.
 * The value of damage "damage" is determined by the weapon held by the 
 * player doing the damage (through CalculateDamage function).
 * parameters: PlayerClass p (player suffering damage)
 * return value: N/A, void function
 * ***********************************************************************/
void PlayerClass::DoDamage(PlayerClass& p){
    int damage;
    damage = WeaponSlot.CalculateDamage(Strength, Skill);
    p.TakeDamage(damage);
}
/* ***********************************************************************
 * function_identifier: This function, by using the SetWeapon function of 
 * the WeaponClass, will equip the player with the specified weapon passed
 * in through the string "wName".
 * parameters: string weapon name "wName"
 * return value: N/A, void function
 * ***********************************************************************/
void PlayerClass::EquipWeapon(string wName){
    WeaponSlot.SetWeapon(wName);
    out << PlayerName << " equipped a " << WeaponSlot.GetName() << "." << endl;
}
//Getter Functions
//getter, returns PlayerType for public access
char PlayerClass::GetPlayerType() const{
    return PlayerType;
}
//getter, returns PlayerName for public access
string PlayerClass::GetPlayerName() const{
    return PlayerName;
}
//getter, returns PlayerCount for public access
int PlayerClass::GetPlayerCount(){
    return PlayerCount;
}

/********************************************************************************************************/
/*                              Red Class                                                             */
/********************************************************************************************************/
class RedClass: public PlayerClass{
public:
    RedClass();                     // Constructor         
    void DoDamage(PlayerClass&);    // DoDamage Override  
};
//constructor, initializes RedClass playerType, playerName, playerStrength,
//and plyerSkill through parent PlayerClass's constructor
RedClass::RedClass() : PlayerClass('r', "Red" + to_string(PlayerCount), 3, 1){};
/* ***********************************************************************
 * function_identifier: This function overrides the DoDamage function in
 * the parent class. It calculates the base damage based on this 
 * player's weapon type with CalculateDamage function of the Weapon class.
 * The base damage is then either doubled, halved, or kept the same 
 * depending on the victim's playerType.
 * It also both couts and writes to the ofstream file that "this" player
 * is attacking the player passed in through the parameters.
 * parameters: PlayerClass p
 * return value: N/A, void function
 * ***********************************************************************/
void RedClass::DoDamage(PlayerClass& p){
    int damage;
    cout << PlayerName << " is attacking " << p.GetPlayerName() << "." << endl;
    out << PlayerName << " is attacking " << p.GetPlayerName() << "." << endl;
    damage = WeaponSlot.CalculateDamage(Strength, Skill);
    switch(p.GetPlayerType()){
        case 'r':
            p.TakeDamage(damage / 2);
            cout << "That was not very effective..." << endl;
            break;
        case 'b':
            p.TakeDamage(damage);
            break;
        case 'g':
            p.TakeDamage(damage * 2);
            cout << "That was super effective!" << endl;
            break;
    }
}
/********************************************************************************************************/
/*                              Blue Class                                                             */
/********************************************************************************************************/
class BlueClass: public PlayerClass{
public:
    BlueClass();                    // Constructor         
    void DoDamage(PlayerClass&);    // DoDamage Override     
};
//constructor, initializes BlueClass playerType, playerName, playerStrength,
//and plyerSkill through parent PlayerClass's constructor
BlueClass::BlueClass() : PlayerClass('b', "Blue" + to_string(PlayerCount), 1, 3){};
/* ***********************************************************************
 * function_identifier: This function overrides the DoDamage function in
 * the parent class. It calculates the base damage based on this 
 * player's weapon type with CalculateDamage function of the Weapon class.
 * The base damage is then either doubled, halved, or kept the same 
 * depending on the victim's playerType.
 * It also both couts and writes to the ofstream file that "this" player
 * is attacking the player passed in through the parameters.
 * parameters: PlayerClass p
 * return value: N/A, void function
 * ***********************************************************************/
void BlueClass::DoDamage(PlayerClass& p){
    int damage;
    cout << PlayerName << " is attacking " << p.GetPlayerName() << "." << endl;
    out << PlayerName << " is attacking " << p.GetPlayerName() << "." << endl;
    damage = WeaponSlot.CalculateDamage(Strength, Skill);
    switch(p.GetPlayerType()){
        case 'r':
            p.TakeDamage(damage * 2);
            cout << "That was super effective!" << endl;
            break;
        case 'b':
            p.TakeDamage(damage / 2);
            cout << "That was not very effective..." << endl;
            break;
        case 'g':
            p.TakeDamage(damage);
            break;
    }
}
/********************************************************************************************************/
/*                              Green Class                                                             */
/********************************************************************************************************/
class GreenClass: public PlayerClass{
public:
    GreenClass();                   // Constructor         
    void DoDamage(PlayerClass&);    // DoDamage Override    
};
//constructor, initializes GreenClass playerType, playerName, playerStrength,
//and plyerSkill through parent PlayerClass's constructor
GreenClass::GreenClass() : PlayerClass('g', "Green" + to_string(PlayerCount), 2, 2){};
/* ***********************************************************************
 * function_identifier: This function overrides the DoDamage function in
 * the parent class. It calculates the base damage based on this 
 * player's weapon type with CalculateDamage function of the Weapon class.
 * The base damage is then either doubled, halved, or kept the same 
 * depending on the victim "p"'s playerType.
 * It also both couts and writes to the ofstream file that "this" player
 * is attacking the player passed in through the parameters.
 * parameters: PlayerClass p
 * return value: N/A, void function
 * ***********************************************************************/
void GreenClass::DoDamage(PlayerClass& p){
    int damage;
    cout << PlayerName << " is attacking " << p.GetPlayerName() << "." << endl;
    out << PlayerName << " is attacking " << p.GetPlayerName() << "." << endl;
    damage = WeaponSlot.CalculateDamage(Strength, Skill);
    switch(p.GetPlayerType()){
        case 'r':
            p.TakeDamage(damage);
            break;
        case 'b':
            p.TakeDamage(damage * 2);
            cout << "That was super effective!" << endl;
            break;
        case 'g':
            p.TakeDamage(damage / 2);
            cout << "That was not very effective..." << endl;
            break;
    }
}
