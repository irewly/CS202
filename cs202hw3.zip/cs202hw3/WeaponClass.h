/* CS 202 FALL 2020
    This skeleton code was developed by James Piotrowski - UNLV Computer Science
*/

#include <string>
using namespace std;

/********************************************************************************************************/
/*                              Weapon Class                                                             */
/********************************************************************************************************/
class WeaponClass {
public:
	WeaponClass();						// Constructor 						
	string GetName();					// GetName returns the WeaponName
	void SetWeapon(string weapon);				// Changes the Weapon Name			
	int CalculateDamage(int Strength, int Skill);		// Determines damage dealt by weapon
private:
	string name;			// The Weapon Name - "Sword", "Bow", "Staff", or "Bare Hands"
	const int Damage = 3;	// Base Damage for all Weapons except Bare Hands
};
//constructor initializes "name" variable to "Bare Hands"
WeaponClass::WeaponClass(){
	name = "Bare Hands";
}
//getter, returns string "name" for public access
string WeaponClass::GetName(){
	return name;
}
/* ***********************************************************************
 * function_identifier: This function will set the weapon name variable
 * "name" inside WeaponClass to the string passed in throught the function
 * If the string passed in does not match any of the four weapon choices
 * the weapon "name" will be set to the default "Bare Hands" and an error
 * message will be couted to the terminal.
 * parameters: string "weapon" for passed in weapon name
 * return value: N/A, void function
 * ***********************************************************************/
void WeaponClass::SetWeapon(string weapon){
	if(weapon != "Sword" && weapon != "Bow" && weapon != "Staff"){
		name = "Bare Hands";
		cout << "ERROR: Unknown Weapon" << endl;
	}
	else{
		name = weapon;
	}
}
/* ***********************************************************************
 * function_identifier: This function will calculate the amount of damage
 * done by various weapons as well as cout the associated weapon sounds to
 * the terminal.
 * parameters: integer "Strength" and integer "Skill"
 * return value: integer value of calculated damage
 * ***********************************************************************/
int WeaponClass::CalculateDamage(int Strength, int Skill){
	if(name == "Sword"){
		cout << "**CLANG**" << endl;
		return Strength * Damage;
	}
	else if(name == "Staff"){
		cout << "**POW**" << endl;
		return Skill * Damage;
	}
	else if(name == "Bow"){
		cout << "**FWOOSH**" << endl;
		return ((Damage - abs(Strength - Skill)) * Damage);
	}
	else{
		cout << "**pfft**" << endl;
		return 1;
	}
}