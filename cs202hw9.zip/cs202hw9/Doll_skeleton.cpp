#include "Doll.h"
//Please disregard how creepy the file name is... Just write the code.

//Prints the Doll's id and name using the printReverse function
void Doll::printDoll() { 
	cout << "Doll " << id << ": ";
	
	/*It looks gross, but endl fixes a bug when compiling with g++ where printReverse() is called out of order. Weird threading issue???
	Using flush() doesn't fix this... endl is not needed if you use Visual Studio */
	cout << endl; 
	printReverse(name, name.length());
	cout << endl << endl;
}

/* Put your function implementations for the Doll class here */
/***********************************************/
/* 					YOUR CODE HERE	   		   */
/* ---- V	V	V	V	V	V	V	V	V ---- */

/* 
  4 Functions
	- insert
	- open
	- removeCenter
	- printReverse

   They should all work recursively. 
   
   Each function can be done in very few lines. 
   *( Solution uses 6 at most, not including bracket lines )*
   You can use more lines, just a reminder to not overthink it!

   If you are having trouble thinking recursively, please Discord/email me
*/

void Doll::insert(Doll* new_doll){
	if(innerDoll == NULL){ //base case, found innermost doll
		innerDoll = new_doll; //insert at end of doll list
		new_doll->innerDoll = NULL; //set new doll's innerDoll pointer to null
		new_doll = NULL; //set new doll to null to avoid dangling pointer
		return;
	}
	innerDoll->insert(new_doll); //recursively loop through till the end of the list
}

void Doll::open(){
	cout << "Opening doll:" << endl; //open doll message
	printDoll(); //call print doll function to print current doll name
	if(innerDoll == NULL){//base case - reached end of doll list
		return; //exit out of function
	}
	innerDoll->open(); //recursive case to print each doll in the list
}

Doll* Doll::removeCenter(){
	if(innerDoll == NULL){ //base case
		return this; //return the outermost doll - "this" pointer
	}
	if(innerDoll->innerDoll == NULL){ //if innermost doll is the next doll
		Doll* found; //create copy pointer
		found = innerDoll; //copy next doll pointer
		innerDoll = NULL; //set next doll pointer to null since the doll will be removed
		return found; //return innermost doll
	}
	return innerDoll->removeCenter(); //recursively extract dolls from the innermost to the outermost
}

void Doll::printReverse(const string& str, int length){
	if(length >= 1){ //base case
		cout << str[length-1]; //cout each letter one by one
		printReverse(str, --length); //recursive case to print entire name string
	}
}
/* ---- ^	^	^	^	^	^	^	^	^ ---- */
/***********************************************/

