using namespace std;
/*****************************************************************************************************************
 *  GLOBAL FUNCTIONS
*****************************************************************************************************************/
/*************************************************
 * CharToInt() 
    -> Converts the char to an int
*************************************************/
int CharToInt( char n ){
    switch(n){
        case '1':{
            return 1;
        }
        case '2':{
            return 2;
        }
        case '3':{
            return 3;
        }
        case '4':{
            return 4;
        }
        case '5':{
            return 5;
        }
        case '6':{
            return 6;
        }
        case '7':{
            return 7;
        }
        case '8':{
            return 8;
        }
        case '9':{
            return 9;
        }
        case '0':{
            return 0;
        }
        default:{
            return 0;
        }
    }
}

/*************************************************
 * IntToChar()
    -> Converts the int to a char
*************************************************/
char IntToChar( int n ){
    switch(n){
        case 1: {
            return '1';
        }
        case 2: {
            return '2';
        }
        case 3: {
            return '3';
        }
        case 4: {
            return '4';
        }
        case 5: {
            return '5';
        }
        case 6: {
            return '6';
        }
        case 7: {
            return '7';
        }
        case 8: {
            return '8';
        }
        case 9: {
            return '9';
        }
        case 0: {
            return '0';
        }
        default:{
            return '\0';
        }
    }
}

/*************************************************
 * CharArrToLong() 
    -> Converts the Array to a Long Int. Needs length
*************************************************/
long int CharArrToLong(const char arr[], int length){
    int Ind = length - 1;
    long int RunningSum = 0;
    unsigned long int mult = 1;
    //loop for remainders
    while(Ind >= 0){
        RunningSum += (CharToInt(arr[Ind--]) * mult);
        mult *= 10;
    }
    return RunningSum;
}

/*************************************************
 * LongToCharArr() 
    -> Converts the Long Int to a Char Arr in pointer form
*************************************************/
char* LongToCharArr(const long int& n){
     char* returnDigits = nullptr;
     if(n > 9){             //If 10 or greater
        int len = 1;        //1's place is at least length 1 (and not divisible by 10)     
        unsigned long int DivCount = n;
        while(DivCount / 10 >= 1){  //For every division
            DivCount /= 10;         //There is 1 added to the length
            len++;
        }
        int ind = len - 1;                      //For decrementing
        returnDigits = new char[len+1];     //Allocate the char array + NULL terminate
        DivCount = n;                       //Reset for conversion
        while(DivCount >= 1){
            returnDigits[ind--] = IntToChar(DivCount%10);   //Assign the character
            DivCount /= 10;
        }
        returnDigits[len] = '\0';
    }
    else{                   //Only length 1
        returnDigits = new char[2];
        returnDigits[0] = IntToChar(n);
        returnDigits[1] = '\0';
    }
    return returnDigits;
}

/*****************************************************************************************************************
 *  CLASS BigNum
*****************************************************************************************************************/
class bigNum {
private:
    char *digits;               //Character array to store the string
    int length;                 //Length of array
    bool invalidNumber;         //If number is negative or contains non numeric chars
public:
    bigNum();                   //Default constructor. Char array contains nothing. Length is ?
    bigNum(string number);      //Will take in the string and store. 
    bigNum(unsigned long int);  //Will convert the number to a string and store
    bigNum(const bigNum &original); //Copy constructor
    ~bigNum();                  //Destructor

    //UNCOMMENT THESE ONE AT A TIME AS YOU DEFINE THEM IN MAIN.CPP
    
    friend bigNum operator+(const bigNum&,const bigNum&);   //+
    friend bigNum operator-(const bigNum&,const bigNum&);   //-
    friend ostream &operator<<( ostream&, const bigNum&);   //<<
    friend istream &operator>>( istream&, bigNum &D );      //>>
    friend bool operator==(const bigNum&,const bigNum&);    //==
    friend bool operator!=(const bigNum&,const bigNum&);    //!=
    friend bigNum operator++(bigNum&);                      //Prefix ++
    friend bigNum operator++(bigNum&, int);                 //Postfix ++
    friend void operator+=(bigNum&,const bigNum&);          //+=
    friend void operator-=(bigNum&,const bigNum&);          //-=
    void operator=(const bigNum&);           //=
    void operator()(const string&);       
};

/*****************************************************************************************************************
 *  CONSTRUCTOR AND DESTRUCTORS
*****************************************************************************************************************/
//DEFAULT CONSTRUCTOR-------------------------------
bigNum::bigNum(){
    length = 0; //empty array - no length
    digits = nullptr; //set digits array pointer to null
    invalidNumber = true; //set invalid flag on
}

//STRING CONSTRUCTOR-----------------------------
bigNum::bigNum(string number){
    invalidNumber = false; //assume it is valid
    length = number.length(); //set digits array length equal to string length
    digits = new char[length]; //allocate digits array 
    
    for(int i = 0; i < number.length() && invalidNumber == false; i++){
        if(isdigit(number[i])){ //check to see if input is valid number
            digits[i] = number[i]; //if yes set digits array content equal to "number"
        }
        else{
            invalidNumber = true; //if input is not valid, set invalid flag on
        }
    }
} 

//LONG INT CONSTRUCTOR--------------------------------
bigNum::bigNum(unsigned long int num){
    invalidNumber = false; //assume it is valid
    int i = 0; //counter used to obtain array length
    char* arr = LongToCharArr(num); //temporary pointer to store LongToCharArr function value
    while (arr[i] != '\0'){ //increase length until terminating character '\0'
        i++;
    }
    
    length = i; //set length equal to i
    digits = new char[length]; //allocate digits array
    for(int j = 0; j < length; j++){
        digits[j] = arr[j]; //set digits array content equal to arr content
    }
    delete [] arr; //de-allocate temporary array "arr"
    arr = NULL; //avoid dangling pointers
}

//COPY CONSTRUCTOR--------------------------------
bigNum::bigNum(const bigNum &original){
    invalidNumber = original.invalidNumber; //set copy's invalidNumber flag equal to original's invalidNumber flag
    length = original.length; //set copy's length equal to original's length
    digits = new char[length]; //allocate copy's digits array
    for(int i = 0; i < length; i++){
        digits[i] = original.digits[i]; //set copy's digits array content equal to original's digits array content
    }
}

//DESTRUCTOR--------------------------------------
bigNum::~bigNum(){
    delete [] digits; //de-allocate digits array
    digits = NULL; //avoid dangling pointers
}