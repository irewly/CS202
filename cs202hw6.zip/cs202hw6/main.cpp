/*
 * Name: Irene Wang, 5005298618, Assignment 6
 * Description: This program will simulate a self-made functional integer 
 * data type where various operations are overloaded to be able to 
 * perform various operations with the bigNum class (such as addition, 
 * subtraction, pre/post increment). It can also read in a file through the
 * overloaded extraction operator and store the content inside a bigNum class.
 * There are various constructors included in the bigNum.h file that can 
 * convert the various inputs into a character array to be stored inside the
 * bigNum class. There is also a destructor that will deallocate the 
 * dynamic digits character array.
 * Input: None from terminal. Various int, string, and bigNum input within the
 * program as well as fstream "TheBigNum.txt".
 * Output: Step-by-step operation titles and corresponding results below. 
 * Invalid operation statements plus invalid number statements.
 */
#include <iostream>
#include <fstream>
#include "bigNum.h"
using namespace std;

/*************************************************
 * Main
 *  No changes Needed
*************************************************/
int main() {
    cout << "STARTING PROGRAM.....\n";
    //CONSTRUCTORS
    cout << endl << "*** BEGIN CONSTRUCTORS ***\n" << endl;
    bigNum* n1 = new bigNum(456);
    bigNum* n2 = new bigNum(345);
    bigNum* n3 = new bigNum("45678900032");
    bigNum* n4 = new bigNum("543278950444503");
    bigNum* n5 = new bigNum();
    bigNum* n6 = new bigNum(*n3);

    //EXTRACTION OPERATOR
    cout << endl << "*** BEGIN EXTRACTION ***\n" << endl;
    cout << *n1 << endl;
    cout << *n2 << endl;

    //ADDITION
    cout << endl << "*** BEGIN ADDITION ***\n" << endl;
    cout << *n1 + *n2 << endl;
    cout << *n3 + *n4 << endl;
    cout << *n3 + *n6 << endl;
    cout << *n5 + *n2 << endl;

    //Subtraction
    cout << endl << "*** BEGIN SUBTRACTION ***\n" << endl;
    cout << *n1 - *n2 << endl;
    cout << *n2 - *n1 << endl;
    cout << *n4 - *n3 << endl;
    cout << *n6 - *n3 << endl;
    cout << *n5 - *n6 << endl;

    //INSERTION
    cout << endl << "*** BEGIN INSERTION ***\n" << endl;
    ifstream f;
    f.open("TheBigNum.txt");
    f >> *n5;
    cout << *n5 << endl;
    f.close();

    //EQUALS AND DOES NOT EQUAL
    cout << endl << "*** BEGIN EQUALITY ***\n" << endl;

    if(*n3 == *n6){
        cout << "EQUAL n3 AND n6" << endl;
    }
    if(*n1 == *n2){
        cout << "EQUAL n1 AND n2" << endl;
    }
    if(*n1 != *n2){
        cout << "NOT EQUAL n1 AND n2" << endl;
    }

    //PREFIX AND POSTFIX
    cout << endl << "*** BEGIN ++ ***\n" << endl;
    cout << ++(*n1) << endl;
    cout << *n1 << endl;

    cout << (*n2)++ << endl;
    cout << *n2 << endl;

    //+= && -=
    cout << endl << "*** BEGIN += & -= ***\n" << endl;
    *n1 += *n2;
    *n4 -= *n3;
    cout << *n1 << endl;
    cout << *n4 << endl;

     //=
    cout << endl << "*** BEGIN ASSIGNMENT ***\n" << endl;
    *n4 = *n2;
    cout << *n2 << endl;
    cout << *n4 << endl;

    //()
    cout << endl << "*** BEGIN () ***\n" << endl;
    (*n5)("123456");
    cout << *n5 << endl;

    delete n1;
    delete n2;
    delete n3;
    delete n4;
    delete n5;
    delete n6;

    return 0;
}
/*************************************************
 * operator<<
    * Output all the digits
*************************************************/
ostream &operator<<(ostream &out, const bigNum &number){
    if(number.invalidNumber == true){ //check to see if "number" is valid
        out << "INVALID NUMBER"; //if not print out invalid message
    }
    else{
        for(int i = 0; i < number.length; i++){
            out << number.digits[i]; //if "number" is valid, print out "number"'s digits array content
        }
    }    
    return out;
}
/*************************************************
 * operator>>
    * puts a new number into the bigNum
*************************************************/
istream &operator>>(istream &in, bigNum &D){
    string temp; //temporary string for getline
    getline(in, temp); //obtain file content
    D(temp); //construct bigNum D with file content stored in temp
    return in;
}

/*************************************************
 * operator+
*************************************************/
bigNum operator+(const bigNum &left, const bigNum &right){
    long int a; //temp int for addition
    long int b; //temp int for addition
    a = CharArrToLong(left.digits, left.length); //store "left"'s digits array content as long int in a
    b = CharArrToLong(right.digits, right.length); //store "right"'s digits arra content as long int in b
    long int sum; //temp int for storing addition sum
    sum = a + b; //perform addition
    bigNum answer(sum); //create bigNum "answer" containing sum
    
    if(left.invalidNumber == true || right.invalidNumber == true){
        answer.invalidNumber = true; //if either input is invalid, turn on answer's invalid flag
        cout << "ADDITION ERROR: 1 or more invalid nums." << endl; //cout invalid message
    }
    
    return answer;
}

/*************************************************
 * operator-
*************************************************/
bigNum operator-(const bigNum &left, const bigNum &right){
    long int a; //temp int for subtraction
    long int b; //temp int for subtraction
    a = CharArrToLong(left.digits, left.length); //store "left"'s digits array content as long int in a
    b = CharArrToLong(right.digits, right.length); //store "right"'s digits arra content as long int in b
    long int difference; //temp int for storing subtraction difference
    difference = a - b; //perform subtraction

    if(left.invalidNumber == true || right.invalidNumber == true){
        cout << "SUBTRACTION ERROR: 1 or more invalid nums." << endl; //if either inputs are invalid, cout invalid operation message
        if(difference < 0){ //if difference is negative
            bigNum answer(difference*(-1)); //store the inverse of difference into new bigNum "answer"
            answer.invalidNumber = true; //turn on answer's invalid flag
            return answer;
        }
        else{
            bigNum answer(difference); //store the difference into new bigNum "answer"
            answer.invalidNumber = true; //turn on answer's invalid flag
            return answer;
        }
    }
    else{ //if both inputs are valid
        if(difference < 0){ //if difference is negative
            bigNum answer(difference*(-1)); //store the inverse of difference into new bigNum "answer"
            answer.invalidNumber = true; //turn on answer's invalid flag
            return answer;
        }
        
        else{
            bigNum answer(difference); //store the difference into new bigNum "answer"
            answer.invalidNumber = false; //turn off answer's invalid flag since answer is valid
            return answer;
        }
    }
}

/*************************************************
 * operator==
    * Return True if the digits are exactly the same
*************************************************/
bool operator==(const bigNum &left,const bigNum &right){
    long int a; //temp long int used for comparison
    long int b; //temp long int used for comparison
    a = CharArrToLong(left.digits, left.length); //store left's digits array content into a
    b = CharArrToLong(right.digits, right.length); //store right's digits array content into b
    if(a == b){ //compare a and b
        return true;
    }
    else{
        return false;
    }
}

/*************************************************
 * operator!=
    * Return True if the digits are not exactly the same
*************************************************/
bool operator!=(const bigNum &left,const bigNum &right){
    long int a; //temp long int used for comparison
    long int b; //temp long int used for comparison
    a = CharArrToLong(left.digits, left.length); //store left's digits array content into a
    b = CharArrToLong(right.digits, right.length); //store right's digits array content into b
    if(a != b){ //compare a and b
        return true;
    }
    else{
        return false;
    }
}

/*************************************************
 * operator++ PREFIX
*************************************************/
bigNum operator++(bigNum &number){
    if(number.invalidNumber == false){ //only perform operation when "number" is valid
        long int temp; //temp long int used for storing number's digits array content
        temp = CharArrToLong(number.digits, number.length); //store number's digits array content into temp
        temp++; //increase temp by 1
        number(to_string(temp)); //reconstruct number/change number content to new value
        return number; //return new "number" value
    }  
}

/*************************************************
 * operator++ POSTFIX
*************************************************/
bigNum operator++(bigNum &BN, int){
    if(BN.invalidNumber == false){ //only perform operation when "number" is valid
        long int temp; //temp long int used for storing number's digits array content
        temp = CharArrToLong(BN.digits, BN.length); //store number's digits array content into temp
        bigNum answer(BN); //create new bigNum "answer" that contains BN's old value
        temp++; //increase temp by 1
        BN(to_string(temp)); //reconstruct BN/change BN content to new value
        return answer; //return old BN value stored in "answer"
    }
}
//YOUR CODE HERE

/*************************************************
 * operator+=
*************************************************/
void operator+=(bigNum &left,const bigNum &right){
    left = left + right; //add left value with right value and store into left
}

/*************************************************
 * operator-=
*************************************************/
void operator-=(bigNum &left,const bigNum &right){
    left = left - right; //subtract right value from left value and store into left
}

/*************************************************
 * operator =
    * 
*************************************************/
void bigNum::operator=(const bigNum &BN){
       length = BN.length; //set length equal to BN's length
       invalidNumber = BN.invalidNumber; //set invalidNumber flag equal to BN's invalid number flag
       for(int i = 0; i < length; i++){
           digits[i] = BN.digits[i]; //set digits array content equal to BN's digits array content
       }
}

/*************************************************
 * operator ()
    * 
*************************************************/
void bigNum::operator()(const string& number){
    delete [] digits; //de-allocate old digits array
    digits = NULL; //avoid dangling pointers
    invalidNumber = false; //assume number is valid
    length = number.length(); //set length equal to string "number"'s length
    digits = new char[length]; //allocate digits char array
    for(int i = 0; i < number.length() && invalidNumber == false; i++){
        if(isdigit(number[i])){ //if "number" is valid
            digits[i] = number[i]; //set digits array content equal to "number"'s content
        }
        else{ //if "number" is invalid
            invalidNumber = true; //turn on invalid number flag
        }
    }
}